# Appointment Booking System

A complete full-stack appointment booking system for clinics with React (Vite) frontend, Spring Boot 3 backend (Java 21), and PostgreSQL database.

## Features

- 📅 Monthly calendar with available / disabled (booked) dates
- 🕒 Time slot selection per doctor per day
- 👨‍⚕️ Doctor list with specializations
- 📝 Booking form with validation
- ✅ Confirmation page
- 📜 Booking history (by patient email)
- ❌ Cancel appointment
- 🔄 Reschedule appointment
- 🎨 Calm blue & green responsive UI

## Tech Stack

| Layer    | Technology                                    |
| -------- | --------------------------------------------- |
| Frontend | React 18 + Vite, Axios, React Router, date-fns |
| Backend  | Spring Boot 3.3, Java 21, Spring Data JPA, Bean Validation |
| Database | PostgreSQL 14+                                |
| Build    | Maven (backend), npm (frontend)               |

## Folder Structure

```
appointment-booking/
├── backend/                       # Spring Boot app
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/clinic/booking/
│       │   ├── BookingApplication.java
│       │   ├── config/CorsConfig.java
│       │   ├── controller/        # REST controllers
│       │   ├── service/           # Business logic
│       │   ├── repository/        # JPA repositories
│       │   ├── model/             # JPA entities
│       │   ├── dto/               # Request/Response DTOs
│       │   └── exception/         # Global exception handler
│       └── resources/
│           └── application.properties
├── frontend/                      # React + Vite app
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── components/
│       ├── pages/
│       ├── services/api.js
│       └── styles/index.css
├── database/
│   └── schema.sql                 # PostgreSQL schema + seed data
├── API.md                         # REST API documentation
└── README.md
```

## Quick Start

### 1. Database (PostgreSQL)

```bash
createdb appointment_db
psql -d appointment_db -f database/schema.sql
```

### 2. Backend (Spring Boot)

Edit `backend/src/main/resources/application.properties` to set your DB credentials, then:

```bash
cd backend
mvn spring-boot:run
```

Backend runs at <http://localhost:8080>.

### 3. Frontend (React + Vite)

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at <http://localhost:5173>.

## API Documentation

See [API.md](./API.md).

## License

MIT
