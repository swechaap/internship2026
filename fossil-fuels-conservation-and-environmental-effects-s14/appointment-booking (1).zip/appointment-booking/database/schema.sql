-- PostgreSQL schema for Appointment Booking System

DROP TABLE IF EXISTS appointments CASCADE;
DROP TABLE IF EXISTS doctors CASCADE;

CREATE TABLE doctors (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(120) NOT NULL,
    specialization  VARCHAR(120) NOT NULL,
    email           VARCHAR(160) NOT NULL UNIQUE,
    bio             TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE appointments (
    id                BIGSERIAL PRIMARY KEY,
    doctor_id         BIGINT NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
    patient_name      VARCHAR(120) NOT NULL,
    patient_email     VARCHAR(160) NOT NULL,
    patient_phone     VARCHAR(40)  NOT NULL,
    appointment_date  DATE NOT NULL,
    appointment_time  TIME NOT NULL,
    reason            VARCHAR(500),
    status            VARCHAR(20) NOT NULL DEFAULT 'BOOKED',
    created_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_doctor_slot UNIQUE (doctor_id, appointment_date, appointment_time)
);

CREATE INDEX idx_appt_email ON appointments(patient_email);
CREATE INDEX idx_appt_doctor_date ON appointments(doctor_id, appointment_date);

-- Seed doctors
INSERT INTO doctors (name, specialization, email, bio) VALUES
('Dr. Sarah Chen',     'Cardiology',     'sarah.chen@clinic.com',     'Board-certified cardiologist with 12 years of experience.'),
('Dr. Marcus Johnson', 'Dermatology',    'marcus.j@clinic.com',       'Specialist in skin health and cosmetic dermatology.'),
('Dr. Priya Patel',    'Pediatrics',     'priya.patel@clinic.com',    'Caring pediatrician focused on child wellness.'),
('Dr. Liam O''Connor', 'General Practice','liam.oconnor@clinic.com',  'Family medicine and preventive care.'),
('Dr. Aiko Tanaka',    'Neurology',      'aiko.tanaka@clinic.com',    'Expert in headache disorders and neurological care.');
