# API Documentation

Base URL: `http://localhost:8080/api`

All requests/responses use `application/json`.

## Doctors

### GET `/api/doctors`
List all doctors.

**200 OK**
```json
[
  { "id": 1, "name": "Dr. Sarah Chen", "specialization": "Cardiology", "email": "sarah@clinic.com" }
]
```

### GET `/api/doctors/{id}`
Get one doctor.

## Appointments

### GET `/api/appointments/booked-slots?doctorId=1&date=2026-07-15`
Returns booked time slots for a given doctor on a given date.

**200 OK**
```json
["09:00", "10:30", "14:00"]
```

### GET `/api/appointments/booked-dates?doctorId=1&month=2026-07`
Returns fully-booked dates (all slots taken) for the month.

**200 OK**
```json
["2026-07-04", "2026-07-18"]
```

### POST `/api/appointments`
Create an appointment.

**Request**
```json
{
  "doctorId": 1,
  "patientName": "John Doe",
  "patientEmail": "john@example.com",
  "patientPhone": "+1-555-0100",
  "appointmentDate": "2026-07-15",
  "appointmentTime": "10:30",
  "reason": "Annual checkup"
}
```

**201 Created** — returns full appointment with `id`, `status: BOOKED`.

**400** — validation error
**409** — slot already booked

### GET `/api/appointments/history?email=john@example.com`
Booking history for a patient (most recent first).

### PUT `/api/appointments/{id}/reschedule`
**Request**
```json
{ "appointmentDate": "2026-07-20", "appointmentTime": "11:00" }
```

### DELETE `/api/appointments/{id}`
Cancel an appointment (sets status to `CANCELLED`).

## Error Response Shape

```json
{ "timestamp": "...", "status": 400, "error": "Validation Failed", "messages": ["patientEmail: must be a valid email"] }
```
