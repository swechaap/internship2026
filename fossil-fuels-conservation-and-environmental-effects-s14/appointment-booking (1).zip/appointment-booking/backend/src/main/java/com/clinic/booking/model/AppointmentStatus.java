package com.clinic.booking.model;

public enum AppointmentStatus {
    BOOKED, CANCELLED, COMPLETED
}
