package com.clinic.booking.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.time.LocalTime;

public record AppointmentRequest(
        @NotNull Long doctorId,
        @NotBlank @Size(max = 120) String patientName,
        @NotBlank @Email @Size(max = 160) String patientEmail,
        @NotBlank @Size(max = 40) String patientPhone,
        @NotNull @FutureOrPresent
        @JsonFormat(pattern = "yyyy-MM-dd") LocalDate appointmentDate,
        @NotNull
        @JsonFormat(pattern = "HH:mm") LocalTime appointmentTime,
        @Size(max = 500) String reason
) {}
