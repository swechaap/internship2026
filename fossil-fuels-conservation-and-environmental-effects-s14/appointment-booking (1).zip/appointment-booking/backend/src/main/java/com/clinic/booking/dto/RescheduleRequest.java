package com.clinic.booking.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

public record RescheduleRequest(
        @NotNull @JsonFormat(pattern = "yyyy-MM-dd") LocalDate appointmentDate,
        @NotNull @JsonFormat(pattern = "HH:mm") LocalTime appointmentTime
) {}
