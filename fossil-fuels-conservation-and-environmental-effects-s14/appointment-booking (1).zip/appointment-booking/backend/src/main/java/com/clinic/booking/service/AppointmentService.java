package com.clinic.booking.service;

import com.clinic.booking.dto.AppointmentRequest;
import com.clinic.booking.dto.AppointmentResponse;
import com.clinic.booking.dto.RescheduleRequest;
import com.clinic.booking.exception.NotFoundException;
import com.clinic.booking.exception.SlotUnavailableException;
import com.clinic.booking.model.Appointment;
import com.clinic.booking.model.AppointmentStatus;
import com.clinic.booking.model.Doctor;
import com.clinic.booking.repository.AppointmentRepository;
import com.clinic.booking.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepo;
    private final DoctorRepository doctorRepo;

    @Value("${clinic.slot.start}") private String slotStart;
    @Value("${clinic.slot.end}")   private String slotEnd;
    @Value("${clinic.slot.minutes}") private int slotMinutes;

    public AppointmentService(AppointmentRepository a, DoctorRepository d) {
        this.appointmentRepo = a; this.doctorRepo = d;
    }

    public List<String> generateAllSlots() {
        var fmt = DateTimeFormatter.ofPattern("HH:mm");
        var start = LocalTime.parse(slotStart, fmt);
        var end = LocalTime.parse(slotEnd, fmt);
        List<String> out = new ArrayList<>();
        for (LocalTime t = start; t.isBefore(end); t = t.plusMinutes(slotMinutes)) {
            out.add(t.format(fmt));
        }
        return out;
    }

    public List<String> bookedSlots(Long doctorId, LocalDate date) {
        doctorRepo.findById(doctorId).orElseThrow(() -> new NotFoundException("Doctor not found"));
        var fmt = DateTimeFormatter.ofPattern("HH:mm");
        return appointmentRepo
                .findByDoctorIdAndAppointmentDateAndStatus(doctorId, date, AppointmentStatus.BOOKED)
                .stream().map(a -> a.getAppointmentTime().format(fmt)).toList();
    }

    /** Dates in the month where ALL slots are booked. */
    public List<LocalDate> fullyBookedDates(Long doctorId, YearMonth month) {
        var totalSlots = generateAllSlots().size();
        var start = month.atDay(1);
        var end = month.atEndOfMonth();
        return appointmentRepo.countBookedPerDate(doctorId, start, end).stream()
                .filter(row -> ((Long) row[1]).intValue() >= totalSlots)
                .map(row -> (LocalDate) row[0])
                .toList();
    }

    @Transactional
    public AppointmentResponse create(AppointmentRequest req) {
        Doctor doctor = doctorRepo.findById(req.doctorId())
                .orElseThrow(() -> new NotFoundException("Doctor not found: " + req.doctorId()));

        validateSlotMatchesClinic(req.appointmentTime());

        appointmentRepo.findByDoctorIdAndAppointmentDateAndAppointmentTimeAndStatus(
                req.doctorId(), req.appointmentDate(), req.appointmentTime(), AppointmentStatus.BOOKED
        ).ifPresent(a -> { throw new SlotUnavailableException("This slot is already booked."); });

        Appointment saved = appointmentRepo.save(Appointment.builder()
                .doctor(doctor)
                .patientName(req.patientName())
                .patientEmail(req.patientEmail())
                .patientPhone(req.patientPhone())
                .appointmentDate(req.appointmentDate())
                .appointmentTime(req.appointmentTime())
                .reason(req.reason())
                .status(AppointmentStatus.BOOKED)
                .build());

        return toResponse(saved);
    }

    public List<AppointmentResponse> history(String email) {
        return appointmentRepo
                .findByPatientEmailOrderByAppointmentDateDescAppointmentTimeDesc(email)
                .stream().map(this::toResponse).toList();
    }

    @Transactional
    public AppointmentResponse reschedule(Long id, RescheduleRequest req) {
        Appointment a = appointmentRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Appointment not found: " + id));
        if (a.getStatus() == AppointmentStatus.CANCELLED)
            throw new SlotUnavailableException("Cannot reschedule a cancelled appointment.");

        validateSlotMatchesClinic(req.appointmentTime());

        appointmentRepo.findByDoctorIdAndAppointmentDateAndAppointmentTimeAndStatus(
                a.getDoctor().getId(), req.appointmentDate(), req.appointmentTime(), AppointmentStatus.BOOKED
        ).ifPresent(existing -> {
            if (!existing.getId().equals(id))
                throw new SlotUnavailableException("New slot is already booked.");
        });

        a.setAppointmentDate(req.appointmentDate());
        a.setAppointmentTime(req.appointmentTime());
        return toResponse(a);
    }

    @Transactional
    public void cancel(Long id) {
        Appointment a = appointmentRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Appointment not found: " + id));
        a.setStatus(AppointmentStatus.CANCELLED);
    }

    private void validateSlotMatchesClinic(LocalTime time) {
        if (!generateAllSlots().contains(time.format(DateTimeFormatter.ofPattern("HH:mm"))))
            throw new SlotUnavailableException("Selected time is outside clinic slots.");
    }

    private AppointmentResponse toResponse(Appointment a) {
        return new AppointmentResponse(
                a.getId(),
                a.getDoctor().getId(),
                a.getDoctor().getName(),
                a.getDoctor().getSpecialization(),
                a.getPatientName(),
                a.getPatientEmail(),
                a.getPatientPhone(),
                a.getAppointmentDate(),
                a.getAppointmentTime(),
                a.getReason(),
                a.getStatus().name()
        );
    }
}
