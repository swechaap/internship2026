package com.clinic.booking.controller;

import com.clinic.booking.dto.AppointmentRequest;
import com.clinic.booking.dto.AppointmentResponse;
import com.clinic.booking.dto.RescheduleRequest;
import com.clinic.booking.service.AppointmentService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    private final AppointmentService service;
    public AppointmentController(AppointmentService service) { this.service = service; }

    @GetMapping("/slots")
    public Map<String, Object> slotInfo(@RequestParam Long doctorId,
                                        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return Map.of(
                "all", service.generateAllSlots(),
                "booked", service.bookedSlots(doctorId, date)
        );
    }

    @GetMapping("/booked-slots")
    public List<String> bookedSlots(@RequestParam Long doctorId,
                                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return service.bookedSlots(doctorId, date);
    }

    @GetMapping("/booked-dates")
    public List<LocalDate> bookedDates(@RequestParam Long doctorId,
                                       @RequestParam String month) {
        return service.fullyBookedDates(doctorId, YearMonth.parse(month));
    }

    @PostMapping
    public ResponseEntity<AppointmentResponse> create(@Valid @RequestBody AppointmentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(req));
    }

    @GetMapping("/history")
    public List<AppointmentResponse> history(@RequestParam String email) {
        return service.history(email);
    }

    @PutMapping("/{id}/reschedule")
    public AppointmentResponse reschedule(@PathVariable Long id, @Valid @RequestBody RescheduleRequest req) {
        return service.reschedule(id, req);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancel(@PathVariable Long id) {
        service.cancel(id);
        return ResponseEntity.noContent().build();
    }
}
