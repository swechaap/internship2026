package com.clinic.booking.controller;

import com.clinic.booking.dto.DoctorDto;
import com.clinic.booking.service.DoctorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {
    private final DoctorService service;
    public DoctorController(DoctorService service) { this.service = service; }

    @GetMapping
    public List<DoctorDto> all() { return service.findAll(); }

    @GetMapping("/{id}")
    public DoctorDto one(@PathVariable Long id) { return service.findById(id); }
}
