package com.clinic.booking.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalTime;

public record AppointmentResponse(
        Long id,
        Long doctorId,
        String doctorName,
        String doctorSpecialization,
        String patientName,
        String patientEmail,
        String patientPhone,
        @JsonFormat(pattern = "yyyy-MM-dd") LocalDate appointmentDate,
        @JsonFormat(pattern = "HH:mm") LocalTime appointmentTime,
        String reason,
        String status
) {}
