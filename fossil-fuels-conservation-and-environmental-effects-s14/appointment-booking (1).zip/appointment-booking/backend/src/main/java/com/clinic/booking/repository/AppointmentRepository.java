package com.clinic.booking.repository;

import com.clinic.booking.model.Appointment;
import com.clinic.booking.model.AppointmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    List<Appointment> findByDoctorIdAndAppointmentDateAndStatus(
            Long doctorId, LocalDate date, AppointmentStatus status);

    Optional<Appointment> findByDoctorIdAndAppointmentDateAndAppointmentTimeAndStatus(
            Long doctorId, LocalDate date, LocalTime time, AppointmentStatus status);

    List<Appointment> findByPatientEmailOrderByAppointmentDateDescAppointmentTimeDesc(String email);

    @Query("""
        SELECT a.appointmentDate, COUNT(a)
        FROM Appointment a
        WHERE a.doctor.id = :doctorId
          AND a.status = com.clinic.booking.model.AppointmentStatus.BOOKED
          AND a.appointmentDate BETWEEN :start AND :end
        GROUP BY a.appointmentDate
    """)
    List<Object[]> countBookedPerDate(@Param("doctorId") Long doctorId,
                                      @Param("start") LocalDate start,
                                      @Param("end") LocalDate end);
}
