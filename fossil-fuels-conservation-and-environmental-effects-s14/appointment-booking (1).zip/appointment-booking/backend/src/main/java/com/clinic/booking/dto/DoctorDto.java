package com.clinic.booking.dto;

public record DoctorDto(Long id, String name, String specialization, String email, String bio) {}
