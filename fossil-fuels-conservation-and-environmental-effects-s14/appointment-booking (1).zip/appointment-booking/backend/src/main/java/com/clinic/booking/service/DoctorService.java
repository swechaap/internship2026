package com.clinic.booking.service;

import com.clinic.booking.dto.DoctorDto;
import com.clinic.booking.exception.NotFoundException;
import com.clinic.booking.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {
    private final DoctorRepository repo;
    public DoctorService(DoctorRepository repo) { this.repo = repo; }

    public List<DoctorDto> findAll() {
        return repo.findAll().stream()
                .map(d -> new DoctorDto(d.getId(), d.getName(), d.getSpecialization(), d.getEmail(), d.getBio()))
                .toList();
    }

    public DoctorDto findById(Long id) {
        var d = repo.findById(id).orElseThrow(() -> new NotFoundException("Doctor not found: " + id));
        return new DoctorDto(d.getId(), d.getName(), d.getSpecialization(), d.getEmail(), d.getBio());
    }
}
