import { Routes, Route, NavLink, Navigate } from 'react-router-dom';
import DoctorsPage from './pages/DoctorsPage.jsx';
import BookingPage from './pages/BookingPage.jsx';
import ConfirmationPage from './pages/ConfirmationPage.jsx';
import HistoryPage from './pages/HistoryPage.jsx';
import ReschedulePage from './pages/ReschedulePage.jsx';

export default function App() {
  return (
    <>
      <nav className="nav">
        <div className="nav-inner">
          <span className="brand">🩺 Calm Clinic</span>
          <NavLink to="/doctors" className={({isActive}) => isActive ? 'active' : ''}>Book</NavLink>
          <NavLink to="/history"  className={({isActive}) => isActive ? 'active' : ''}>My Appointments</NavLink>
        </div>
      </nav>

      <main className="container">
        <Routes>
          <Route path="/" element={<Navigate to="/doctors" replace />} />
          <Route path="/doctors" element={<DoctorsPage />} />
          <Route path="/book/:doctorId" element={<BookingPage />} />
          <Route path="/confirmation" element={<ConfirmationPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/reschedule/:id" element={<ReschedulePage />} />
          <Route path="*" element={<div className="card">Page not found.</div>} />
        </Routes>
      </main>
    </>
  );
}
