import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { format } from 'date-fns';
import { DoctorsAPI, AppointmentsAPI } from '../services/api';
import Calendar from '../components/Calendar.jsx';
import TimeSlots from '../components/TimeSlots.jsx';

export default function BookingPage() {
  const { doctorId } = useParams();
  const nav = useNavigate();
  const [doctor, setDoctor] = useState(null);
  const [date, setDate] = useState(null);
  const [time, setTime] = useState(null);
  const [form, setForm] = useState({ patientName: '', patientEmail: '', patientPhone: '', reason: '' });
  const [err, setErr] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { DoctorsAPI.get(doctorId).then(setDoctor); }, [doctorId]);

  const update = (k) => (e) => setForm(s => ({ ...s, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    if (!date || !time) { setErr('Please pick a date and time.'); return; }
    setSubmitting(true);
    try {
      const payload = {
        doctorId: Number(doctorId),
        ...form,
        appointmentDate: format(date, 'yyyy-MM-dd'),
        appointmentTime: time,
      };
      const created = await AppointmentsAPI.create(payload);
      nav('/confirmation', { state: { appointment: created } });
    } catch (e) {
      const msgs = e?.response?.data?.messages;
      setErr(Array.isArray(msgs) ? msgs.join(' • ') : (e?.message || 'Failed to book'));
    } finally { setSubmitting(false); }
  };

  if (!doctor) return <p className="muted">Loading…</p>;

  return (
    <>
      <Link to="/doctors" className="muted">← Back to doctors</Link>
      <h1 style={{marginTop: '0.5rem'}}>Book with {doctor.name}</h1>
      <p className="specialization">{doctor.specialization}</p>

      <div className="grid cols-2" style={{marginTop: '1rem'}}>
        <Calendar doctorId={Number(doctorId)} selectedDate={date} onSelect={(d) => { setDate(d); setTime(null); }} />
        <div className="card">
          <h2>Available time slots</h2>
          <TimeSlots doctorId={Number(doctorId)} date={date} selected={time} onSelect={setTime} />
        </div>
      </div>

      <form className="card" onSubmit={submit} style={{marginTop: '1rem'}}>
        <h2>Your details</h2>
        <div className="grid cols-2">
          <div>
            <label>Full name</label>
            <input required maxLength={120} value={form.patientName} onChange={update('patientName')} />
          </div>
          <div>
            <label>Email</label>
            <input required type="email" maxLength={160} value={form.patientEmail} onChange={update('patientEmail')} />
          </div>
          <div>
            <label>Phone</label>
            <input required maxLength={40} value={form.patientPhone} onChange={update('patientPhone')} />
          </div>
          <div>
            <label>Selected</label>
            <input disabled value={date && time ? `${format(date, 'PP')} at ${time}` : 'Pick a date and time'} />
          </div>
        </div>
        <div style={{marginTop: '0.75rem'}}>
          <label>Reason (optional)</label>
          <textarea maxLength={500} value={form.reason} onChange={update('reason')} />
        </div>
        {err && <p className="error">{err}</p>}
        <div className="toolbar" style={{marginTop: '1rem'}}>
          <button className="btn green" type="submit" disabled={submitting}>
            {submitting ? 'Booking…' : 'Confirm booking'}
          </button>
        </div>
      </form>
    </>
  );
}
