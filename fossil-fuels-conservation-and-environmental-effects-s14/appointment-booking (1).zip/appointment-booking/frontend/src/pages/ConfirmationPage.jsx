import { Link, useLocation, Navigate } from 'react-router-dom';

export default function ConfirmationPage() {
  const { state } = useLocation();
  const a = state?.appointment;
  if (!a) return <Navigate to="/doctors" replace />;

  return (
    <>
      <div className="success-banner">✅ Your appointment has been booked.</div>
      <div className="card">
        <h1>Confirmation</h1>
        <p><strong>Doctor:</strong> {a.doctorName} <span className="specialization">({a.doctorSpecialization})</span></p>
        <p><strong>Date:</strong> {a.appointmentDate} at <strong>{a.appointmentTime}</strong></p>
        <p><strong>Patient:</strong> {a.patientName} — {a.patientEmail} — {a.patientPhone}</p>
        {a.reason && <p><strong>Reason:</strong> {a.reason}</p>}
        <p><strong>Reference:</strong> #{a.id}</p>

        <div className="toolbar" style={{marginTop: '1rem'}}>
          <Link to="/history" className="btn">View my appointments</Link>
          <Link to="/doctors" className="btn ghost">Book another</Link>
        </div>
      </div>
    </>
  );
}
