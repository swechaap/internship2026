import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { DoctorsAPI } from '../services/api';

export default function DoctorsPage() {
  const [doctors, setDoctors] = useState([]);
  const [err, setErr] = useState('');

  useEffect(() => {
    DoctorsAPI.list().then(setDoctors).catch(e => setErr(e?.message || 'Failed to load'));
  }, []);

  return (
    <>
      <h1>Choose a doctor</h1>
      <p className="muted">Browse our specialists and book a convenient time.</p>
      {err && <p className="error">{err}</p>}
      <div className="grid cols-3" style={{marginTop: '1rem'}}>
        {doctors.map(d => (
          <Link key={d.id} to={`/book/${d.id}`} style={{textDecoration:'none', color:'inherit'}}>
            <div className="card doctor-card">
              <h2 style={{marginBottom: 4}}>{d.name}</h2>
              <div className="specialization">{d.specialization}</div>
              <p className="muted" style={{marginTop: '0.5rem'}}>{d.bio}</p>
              <button className="btn green" style={{marginTop: '0.75rem'}}>Book appointment</button>
            </div>
          </Link>
        ))}
      </div>
    </>
  );
}
