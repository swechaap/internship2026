import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AppointmentsAPI } from '../services/api';

export default function HistoryPage() {
  const [email, setEmail] = useState(localStorage.getItem('lastEmail') || '');
  const [items, setItems] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [err, setErr] = useState('');

  const load = async (e) => {
    e?.preventDefault();
    setErr('');
    try {
      const data = await AppointmentsAPI.history(email);
      localStorage.setItem('lastEmail', email);
      setItems(data); setLoaded(true);
    } catch (e) { setErr(e?.message || 'Failed'); }
  };

  const cancel = async (id) => {
    if (!confirm('Cancel this appointment?')) return;
    await AppointmentsAPI.cancel(id);
    load();
  };

  return (
    <>
      <h1>My appointments</h1>
      <form className="card" onSubmit={load}>
        <label>Enter your email to view your bookings</label>
        <div className="row" style={{marginTop: '0.5rem'}}>
          <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" />
          <button className="btn" type="submit">Look up</button>
        </div>
        {err && <p className="error">{err}</p>}
      </form>

      {loaded && (
        <div className="card" style={{marginTop: '1rem'}}>
          {items.length === 0 && <p className="muted">No appointments found for this email.</p>}
          {items.map(a => (
            <div key={a.id} className="appt-item">
              <div>
                <div><strong>{a.doctorName}</strong> <span className="specialization">— {a.doctorSpecialization}</span></div>
                <div className="muted">{a.appointmentDate} at {a.appointmentTime}</div>
                {a.reason && <div className="muted">Reason: {a.reason}</div>}
                <span className={`badge ${a.status}`} style={{marginTop: '0.4rem', display:'inline-block'}}>{a.status}</span>
              </div>
              <div className="toolbar">
                {a.status === 'BOOKED' && (
                  <>
                    <Link to={`/reschedule/${a.id}`} state={{ appointment: a }} className="btn ghost">Reschedule</Link>
                    <button className="btn danger" onClick={() => cancel(a.id)}>Cancel</button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
