import { useEffect, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { format } from 'date-fns';
import { AppointmentsAPI } from '../services/api';
import Calendar from '../components/Calendar.jsx';
import TimeSlots from '../components/TimeSlots.jsx';

export default function ReschedulePage() {
  const { id } = useParams();
  const { state } = useLocation();
  const nav = useNavigate();
  const appt = state?.appointment;

  const [date, setDate] = useState(appt ? new Date(appt.appointmentDate) : null);
  const [time, setTime] = useState(appt?.appointmentTime || null);
  const [err, setErr] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (!appt) nav('/history'); }, [appt, nav]);
  if (!appt) return null;

  const save = async () => {
    setErr('');
    if (!date || !time) { setErr('Pick a date and time.'); return; }
    setSaving(true);
    try {
      await AppointmentsAPI.reschedule(id, {
        appointmentDate: format(date, 'yyyy-MM-dd'),
        appointmentTime: time,
      });
      nav('/history');
    } catch (e) {
      const msgs = e?.response?.data?.messages;
      setErr(Array.isArray(msgs) ? msgs.join(' • ') : 'Failed to reschedule');
    } finally { setSaving(false); }
  };

  return (
    <>
      <h1>Reschedule appointment</h1>
      <p className="muted">With <strong>{appt.doctorName}</strong> ({appt.doctorSpecialization})</p>

      <div className="grid cols-2" style={{marginTop: '1rem'}}>
        <Calendar doctorId={appt.doctorId} selectedDate={date} onSelect={(d) => { setDate(d); setTime(null); }} />
        <div className="card">
          <h2>Pick a new time</h2>
          <TimeSlots doctorId={appt.doctorId} date={date} selected={time} onSelect={setTime} />
        </div>
      </div>

      {err && <p className="error">{err}</p>}
      <div className="toolbar" style={{marginTop: '1rem'}}>
        <button className="btn green" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save changes'}</button>
        <button className="btn ghost" onClick={() => nav('/history')}>Back</button>
      </div>
    </>
  );
}
