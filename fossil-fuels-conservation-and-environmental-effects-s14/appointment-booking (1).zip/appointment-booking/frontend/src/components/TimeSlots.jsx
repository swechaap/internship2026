import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { AppointmentsAPI } from '../services/api';

export default function TimeSlots({ doctorId, date, selected, onSelect }) {
  const [all, setAll] = useState([]);
  const [booked, setBooked] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!doctorId || !date) return;
    setLoading(true);
    AppointmentsAPI.slots(doctorId, format(date, 'yyyy-MM-dd'))
      .then(d => { setAll(d.all || []); setBooked(d.booked || []); })
      .finally(() => setLoading(false));
  }, [doctorId, date]);

  if (!date) return <p className="muted">Pick a date to see time slots.</p>;
  if (loading) return <p className="muted">Loading slots…</p>;

  return (
    <div className="slots">
      {all.map(t => {
        const isBooked = booked.includes(t);
        const cls = ['slot', isBooked ? 'booked' : '', selected === t ? 'selected' : ''].join(' ').trim();
        return (
          <div key={t} className={cls} onClick={() => !isBooked && onSelect(t)}>{t}</div>
        );
      })}
    </div>
  );
}
