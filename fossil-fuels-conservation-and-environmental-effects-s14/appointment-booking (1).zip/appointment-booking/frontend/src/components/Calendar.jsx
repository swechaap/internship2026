import { useEffect, useState } from 'react';
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek,
  addDays, format, isSameMonth, isSameDay, isBefore, startOfToday, addMonths,
} from 'date-fns';
import { AppointmentsAPI } from '../services/api';

const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function Calendar({ doctorId, selectedDate, onSelect }) {
  const [cursor, setCursor] = useState(startOfMonth(selectedDate || new Date()));
  const [fullyBooked, setFullyBooked] = useState(new Set());
  const today = startOfToday();

  useEffect(() => {
    if (!doctorId) return;
    const month = format(cursor, 'yyyy-MM');
    AppointmentsAPI.bookedDates(doctorId, month)
      .then(dates => setFullyBooked(new Set(dates)))
      .catch(() => setFullyBooked(new Set()));
  }, [doctorId, cursor]);

  const start = startOfWeek(startOfMonth(cursor));
  const end = endOfWeek(endOfMonth(cursor));
  const days = [];
  for (let d = start; d <= end; d = addDays(d, 1)) days.push(d);

  return (
    <div className="calendar card">
      <div className="cal-head">
        <button className="btn ghost" onClick={() => setCursor(addMonths(cursor, -1))}>‹</button>
        <h3>{format(cursor, 'MMMM yyyy')}</h3>
        <button className="btn ghost" onClick={() => setCursor(addMonths(cursor, 1))}>›</button>
      </div>
      <div className="cal-grid">
        {DOW.map(d => <div key={d} className="cal-dow">{d}</div>)}
        {days.map(day => {
          const outside = !isSameMonth(day, cursor);
          const past = isBefore(day, today);
          const iso = format(day, 'yyyy-MM-dd');
          const booked = fullyBooked.has(iso);
          const disabled = past || booked;
          const cls = [
            'cal-day',
            outside ? 'empty' : '',
            past ? 'past' : '',
            booked ? 'disabled' : '',
            selectedDate && isSameDay(day, selectedDate) ? 'selected' : '',
            isSameDay(day, today) ? 'today' : '',
          ].join(' ').trim();
          return (
            <div
              key={iso}
              className={cls}
              title={booked ? 'Fully booked' : ''}
              onClick={() => { if (!outside && !disabled) onSelect(day); }}
            >
              {outside ? '' : format(day, 'd')}
            </div>
          );
        })}
      </div>
      <p className="muted" style={{marginTop: '0.75rem'}}>
        Strike-through dates are fully booked or in the past.
      </p>
    </div>
  );
}
