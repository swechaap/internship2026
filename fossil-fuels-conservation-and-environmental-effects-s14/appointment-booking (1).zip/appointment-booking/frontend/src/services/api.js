import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export const DoctorsAPI = {
  list: () => api.get('/doctors').then(r => r.data),
  get:  (id) => api.get(`/doctors/${id}`).then(r => r.data),
};

export const AppointmentsAPI = {
  slots: (doctorId, date) =>
    api.get('/appointments/slots', { params: { doctorId, date } }).then(r => r.data),
  bookedDates: (doctorId, month) =>
    api.get('/appointments/booked-dates', { params: { doctorId, month } }).then(r => r.data),
  create: (payload) => api.post('/appointments', payload).then(r => r.data),
  history: (email) => api.get('/appointments/history', { params: { email } }).then(r => r.data),
  reschedule: (id, payload) => api.put(`/appointments/${id}/reschedule`, payload).then(r => r.data),
  cancel: (id) => api.delete(`/appointments/${id}`).then(r => r.data),
};

export default api;
