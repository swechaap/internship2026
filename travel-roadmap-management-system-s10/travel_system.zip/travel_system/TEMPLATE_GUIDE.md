# 📄 Template Reference Guide

## Overview of All HTML Templates

### 1. **base.html** - Master Template
**Purpose**: Base template for all pages
**Features**:
- Navigation bar with branding
- Sidebar menu with all module links
- Flash messages support
- Footer
- Template blocks for inheritance

**Navigation Sections**:
- Dashboard
- Trip Management (Trips, Create Trip)
- Planning (Destinations, Schedule, Roadmap, Itinerary)
- Bookings (Hotels, Transport, Activities)
- Management (Expenses, Tracking, Feedback)
- Insights (Reports, Profile)

---

### 2. **login.html** - User Login
**Module**: User Authentication
**Features**:
- Email input
- Password input
- Remember me checkbox
- Forgot password link
- Register link
- Gradient background
- Animated form

---

### 3. **register.html** - User Registration
**Module**: User Authentication
**Features**:
- Full name input
- Email input
- Password input
- Confirm password
- Terms & conditions checkbox
- Login link
- Beautiful gradient design

---

### 4. **dashboard.html** - Main Dashboard
**Module**: Dashboard Management
**Features**:
- Stats cards (Active trips, upcoming trips, expenses, destinations)
- Quick action buttons
- Recent notifications feed
- Recent trips table
- Featured destinations cards
- Performance metrics

---

### 5. **profile.html** - User Profile
**Module**: User Profile Management
**Features**:
- Account information form
- Settings & preferences
- Notification settings
- Change password form
- Account actions (download data, deactivate, delete)
- Avatar placeholder

---

### 6. **trips.html** - My Trips
**Module**: Trip Management
**Features**:
- Trip status filter
- Search functionality
- Grid layout of trip cards
- Trip details (destination, duration, budget)
- Status badges
- View/Edit actions
- Create new trip button

---

### 7. **create_trip.html** - Create New Trip
**Module**: Trip Management
**Features**:
- Trip name input
- Trip description
- Start & end date picker
- Budget input
- Trip type selector
- Number of travelers
- Trip planning steps guide
- Popular trip ideas

---

### 8. **destinations.html** - Destination Management
**Module**: Destination Management
**Features**:
- Destination search
- Add destination form
- Category selector
- Duration & budget inputs
- Popular destinations list
- Selected destinations table (drag-to-reorder)
- Distance information
- Weather details
- Best time to visit

---

### 9. **schedule.html** - Travel Schedule
**Module**: Travel Schedule Management
**Features**:
- Trip start/end date picker
- Destination-specific date ranges
- Total duration display
- Timeline visualization
- Calendar view
- Date formatting
- Timeline with visual indicators

---

### 10. **roadmap.html** - Travel Roadmap
**Module**: Travel Roadmap Generation
**Features**:
- Route optimization options
- Transportation mode selection
- Route summary (distance, time, cost, rating)
- Detailed route sequence table
- Alternative route suggestions
- Traffic avoidance option
- Route metrics display

---

### 11. **itinerary.html** - Itinerary Management
**Module**: Itinerary Management
**Features**:
- Date picker for filtering
- Day-wise itinerary cards
- Activity cards with times
- Add activity button for each day
- Complete timeline view
- Activity details
- Color-coded days

---

### 12. **hotels.html** - Hotel Booking
**Module**: Hotel Booking Management
**Features**:
- Search filters (destination, dates, guests, star rating, price)
- Hotel cards with:
  - Hotel image placeholder
  - Rating & reviews
  - Price information
  - Amenities list
  - View details & book buttons
- Booked hotels table
- Hotel details

---

### 13. **transport.html** - Transportation Booking
**Module**: Transportation Management
**Features**:
- Tab-based booking (Flights, Trains, Cars)
- Search filters
- Flight result cards
- Flight details (time, duration, route)
- Baggage information
- Price comparison
- Booked transportation table

---

### 14. **activities.html** - Activity Management
**Module**: Activity Management
**Features**:
- Activity search by destination
- Category filtering
- Featured activities cards
- Activity ratings & reviews
- Duration & pricing
- Add to itinerary button
- My scheduled activities table
- Activity status tracking

---

### 15. **expenses.html** - Expense Management
**Module**: Expense Management
**Features**:
- Budget overview cards
- Add expense form
- Category selector
- Date & payment method picker
- Budget breakdown progress bars
- Recent expenses table
- Category-wise spending visualization
- Budget alerts

---

### 16. **notifications.html** - Notifications
**Module**: Notification Management
**Features**:
- Notification filtering
- Sort options
- Notification cards with:
  - Icon & type
  - Title & message
  - Timestamp
  - Mark as read button
- Notification types (booking, alert, reminder, update)
- Notification settings

---

### 17. **tracking.html** - Trip Tracking
**Module**: Trip Tracking
**Features**:
- Current location display
- Day number indicator
- Progress percentage
- Journey progress bar
- Daily checklist with checkboxes
- Daily log section
- Memory notes input
- Journey map placeholder

---

### 18. **feedback.html** - Feedback & Reviews
**Module**: Feedback & Review Management
**Features**:
- Review submission form
- Rating selector (star system)
- Review title & content
- Recommendation options
- Previous reviews display
- Edit/Delete review options
- Helpful voting
- Review statistics
- Tips section

---

### 19. **reports.html** - Reports & Analytics
**Module**: Reports & Analytics
**Features**:
- Trip selector & date range
- Summary stats cards
- Expense breakdown charts
- Daily spending trend visualization
- Destination summary table
- Activities summary table
- Key metrics cards
- Budget analysis
- Export options (PDF, Excel, Email, Print)

---

## 🎨 Template Features

### Common Elements
- Professional card design
- Gradient headers
- Status badges
- Progress bars
- Action buttons
- Form inputs with validation
- Data tables
- Icon usage throughout

### Color Coding System
- **Blue (#3498db)**: Primary actions, links
- **Green (#27ae60)**: Success, confirmed
- **Orange (#f39c12)**: Warnings, pending
- **Red (#e74c3c)**: Danger, errors
- **Gray (#7f8c8d)**: Secondary text, disabled

### Standard Patterns
1. **Header**: Page title + description
2. **Forms**: Organized form groups with labels
3. **Cards**: Consistent padding and shadows
4. **Tables**: Striped rows, hover effects
5. **Buttons**: Consistent sizing and styles
6. **Badges**: Status indicators
7. **Notifications**: Toast-style alerts

---

## 📱 Responsive Behavior

All templates are responsive:
- **Desktop**: Full sidebar + full width content
- **Tablet**: Adjusted sidebar width, responsive grid
- **Mobile**: Collapsed sidebar, single column layout

---

## 🔗 Template Relationships

```
base.html (Master Template)
├── login.html (Public)
├── register.html (Public)
└── dashboard.html (Protected - extends base.html)
    ├── profile.html
    ├── trips.html
    ├── create_trip.html
    ├── destinations.html
    ├── schedule.html
    ├── roadmap.html
    ├── itinerary.html
    ├── hotels.html
    ├── transport.html
    ├── activities.html
    ├── expenses.html
    ├── notifications.html
    ├── tracking.html
    ├── feedback.html
    └── reports.html
```

---

## 🚀 Using These Templates

### To Customize a Template:
1. Open the template file from `templates/` folder
2. Modify HTML structure or styling
3. Update colors in CSS variables (in `static/css/style.css`)
4. Add your own images and content
5. Refresh browser to see changes

### To Add a New Template:
1. Create new `.html` file in `templates/` folder
2. Extend `base.html`: `{% extends "base.html" %}`
3. Add content in blocks: `{% block content %}`
4. Add route in `app.py`
5. Link it in navigation

---

## 📝 Notes

- All templates use Jinja2 templating syntax
- Forms are styled with custom CSS classes
- Images use placeholder elements (ready for real images)
- All links are functional within the application
- Session variables display user name where applicable
- Navigation highlights current page

---

**Last Updated**: 2024
**Template Count**: 19 files
**Total Content**: 5,000+ lines of HTML
