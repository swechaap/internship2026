from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from datetime import datetime, timedelta
import json

app = Flask(__name__)
app.secret_key = 'travel_system_secret_key_2024'

# Simulated data storage
users_db = {}
trips_db = {}
bookings_db = {}
expenses_db = {}
notifications_db = {}

# ==================== Authentication Routes ====================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        try:
            email = request.form.get('email', '').strip()
            password = request.form.get('password', '').strip()
            
            # Validate inputs
            if not email or not password:
                error = 'Email and password are required'
            elif len(email) < 5 or '@' not in email:
                error = 'Please enter a valid email address'
            elif len(password) < 6:
                error = 'Password must be at least 6 characters'
            else:
                # Simulated authentication - accept any valid email/password combo
                session['user_id'] = email
                session['user_name'] = email.split('@')[0]
                return redirect(url_for('dashboard'))
        except Exception as e:
            error = f'Login error: {str(e)}'
    
    return render_template('login.html', error=error)

@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        try:
            name = request.form.get('name', '').strip()
            email = request.form.get('email', '').strip()
            password = request.form.get('password', '').strip()
            confirm_password = request.form.get('confirm_password', '').strip()
            
            # Validate inputs
            if not all([name, email, password, confirm_password]):
                error = 'All fields are required'
            elif len(name) < 2:
                error = 'Name must be at least 2 characters'
            elif len(email) < 5 or '@' not in email:
                error = 'Please enter a valid email address'
            elif len(password) < 6:
                error = 'Password must be at least 6 characters'
            elif password != confirm_password:
                error = 'Passwords do not match'
            elif email in users_db:
                error = 'Email already registered'
            else:
                # Store user data
                users_db[email] = {
                    'name': name,
                    'email': email,
                    'password': password,
                    'created_at': datetime.now()
                }
                session['user_id'] = email
                session['user_name'] = name
                return redirect(url_for('dashboard'))
        except Exception as e:
            error = f'Registration error: {str(e)}'
    
    return render_template('register.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('profile.html', user_name=session.get('user_name'))

# ==================== Dashboard Routes ====================

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    # Simulated data
    active_trips = 2
    upcoming_trips = 3
    total_expenses = 5450
    return render_template('dashboard.html', 
                         user_name=session.get('user_name'),
                         active_trips=active_trips,
                         upcoming_trips=upcoming_trips,
                         total_expenses=total_expenses)

# ==================== Trip Management Routes ====================

@app.route('/trips')
def trips():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('trips.html', user_name=session.get('user_name'))

@app.route('/create-trip', methods=['GET', 'POST'])
def create_trip():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        trip_name = request.form.get('trip_name')
        return redirect(url_for('destination_management'))
    return render_template('create_trip.html', user_name=session.get('user_name'))

# ==================== Destination Management Routes ====================

@app.route('/destinations')
def destination_management():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('destinations.html', user_name=session.get('user_name'))

# ==================== Schedule Management Routes ====================

@app.route('/schedule')
def schedule_management():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('schedule.html', user_name=session.get('user_name'))

# ==================== Travel Roadmap Routes ====================

@app.route('/roadmap')
def roadmap_generation():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('roadmap.html', user_name=session.get('user_name'))

# ==================== Itinerary Routes ====================

@app.route('/itinerary')
def itinerary_management():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('itinerary.html', user_name=session.get('user_name'))

# ==================== Booking Routes ====================

@app.route('/hotels')
def hotel_booking():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('hotels.html', user_name=session.get('user_name'))

@app.route('/transport')
def transport_booking():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('transport.html', user_name=session.get('user_name'))

# ==================== Activity Routes ====================

@app.route('/activities')
def activity_management():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('activities.html', user_name=session.get('user_name'))

# ==================== Expense Routes ====================

@app.route('/expenses')
def expense_management():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('expenses.html', user_name=session.get('user_name'))

# ==================== Notification Routes ====================

@app.route('/notifications')
def notifications():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('notifications.html', user_name=session.get('user_name'))

# ==================== Tracking Routes ====================

@app.route('/tracking')
def trip_tracking():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('tracking.html', user_name=session.get('user_name'))

# ==================== Feedback Routes ====================

@app.route('/feedback')
def feedback_management():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('feedback.html', user_name=session.get('user_name'))

# ==================== Reports Routes ====================

@app.route('/reports')
def reports():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('reports.html', user_name=session.get('user_name'))

# ==================== API Routes ====================

@app.route('/api/trips', methods=['GET', 'POST'])
def api_trips():
    if request.method == 'POST':
        return jsonify({'status': 'success', 'message': 'Trip created'})
    return jsonify({'trips': []})

@app.route('/api/expenses', methods=['GET', 'POST'])
def api_expenses():
    if request.method == 'POST':
        return jsonify({'status': 'success', 'message': 'Expense added'})
    return jsonify({'expenses': []})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
