# 🚀 Quick Start Guide

Get the Travel Roadmap Management System running in 5 minutes!

## Step 1: Install Python (if not already installed)

Download Python 3.7+ from: https://www.python.org/

## Step 2: Open Terminal/Command Prompt

Navigate to the project folder:
```bash
cd travel_system
```

## Step 3: Create Virtual Environment

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

You should see `(venv)` at the beginning of your terminal line.

## Step 4: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install Flask and all required packages.

## Step 5: Run the Application

```bash
python app.py
```

You should see output like:
```
 * Running on http://127.0.0.1:5000
 * Debug mode: on
```

## Step 6: Open in Browser

Visit: **http://localhost:5000**

## Step 7: Login

Use any email and password (demo mode accepts all):
- Email: `test@example.com`
- Password: `any-password`

Or create a new account by clicking "Register"

## 🎉 You're Ready!

Explore the features:
- 📊 Dashboard - Overview of trips
- 🗺️ Trips - View and create trips
- 📍 Destinations - Manage locations
- 🏨 Hotels - Search accommodations
- ✈️ Transport - Book flights
- 💰 Expenses - Track spending
- 📊 Reports - Analytics

## Troubleshooting

### Port 5000 already in use?
```bash
python app.py --port 5001
```

### Module not found error?
Reinstall requirements:
```bash
pip install -r requirements.txt --force-reinstall
```

### Virtual environment issues?
Delete venv folder and recreate:
```bash
rmdir venv  # Windows: rmdir /s venv
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## 📱 Access from Other Devices

Find your computer's IP:

**Windows:**
```bash
ipconfig
```

**macOS/Linux:**
```bash
ifconfig
```

Look for "IPv4 Address" (typically starts with 192.168.x.x)

Then visit: `http://YOUR_IP:5000`

## 🛑 Stop the Server

Press `Ctrl+C` in the terminal

## Next Steps

1. Explore all 15 modules
2. Check out the professional design and animations
3. Customize colors in `static/css/style.css`
4. Add your own images to `static/images/`
5. Integrate with a real database (see README.md)

Happy travels! 🌍✈️🏖️
