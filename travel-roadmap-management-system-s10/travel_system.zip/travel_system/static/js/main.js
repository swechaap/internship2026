// Travel Roadmap Management System - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initializeAnimations();
    
    // Initialize interactive elements
    initializeInteractiveElements();
    
    // Add event listeners
    attachEventListeners();
});

// Animations
function initializeAnimations() {
    // Add fade-in animation to cards on load
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.animation = `fadeInUp 0.6s ease ${index * 0.1}s both`;
    });
}

// Interactive Elements
function initializeInteractiveElements() {
    // Hover effects for sidebar links
    const sidebarLinks = document.querySelectorAll('.sidebar-menu a');
    sidebarLinks.forEach(link => {
        if (link.href === window.location.href) {
            link.classList.add('active');
        }
    });

    // Rating stars
    const starContainers = document.querySelectorAll('[data-rating]');
    starContainers.forEach(container => {
        const stars = container.querySelectorAll('.star');
        stars.forEach((star, index) => {
            star.addEventListener('click', function() {
                setRating(container, index + 1);
            });
            star.addEventListener('mouseover', function() {
                highlightRating(container, index + 1);
            });
        });
        container.addEventListener('mouseleave', function() {
            resetRatingDisplay(container);
        });
    });
}

// Set rating
function setRating(container, rating) {
    container.setAttribute('data-rating', rating);
    updateRatingDisplay(container, rating);
}

// Highlight rating on hover
function highlightRating(container, rating) {
    updateRatingDisplay(container, rating);
}

// Reset rating display
function resetRatingDisplay(container) {
    const currentRating = container.getAttribute('data-rating') || 0;
    updateRatingDisplay(container, currentRating);
}

// Update rating display
function updateRatingDisplay(container, rating) {
    const stars = container.querySelectorAll('.star');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.add('filled');
        } else {
            star.classList.remove('filled');
        }
    });
}

// Event Listeners
function attachEventListeners() {
    // Form submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            handleFormSubmit(e, form);
        });
    });

    // Modal close buttons
    const closeButtons = document.querySelectorAll('.close');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            const modal = e.target.closest('.modal');
            if (modal) {
                closeModal(modal);
            }
        });
    });

    // Notification dismiss
    const dismissButtons = document.querySelectorAll('[data-dismiss]');
    dismissButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const alert = this.closest('.alert');
            if (alert) {
                alert.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => alert.remove(), 300);
            }
        });
    });

    // Tab switching
    const tabButtons = document.querySelectorAll('[data-tab]');
    tabButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.getAttribute('data-tab'));
        });
    });

    // Search functionality
    const searchInputs = document.querySelectorAll('[data-search]');
    searchInputs.forEach(input => {
        input.addEventListener('keyup', function() {
            performSearch(this.value, this.getAttribute('data-search'));
        });
    });
}

// Form submission handler
function handleFormSubmit(e, form) {
    const button = form.querySelector('button[type="submit"]');
    if (button) {
        button.innerHTML = '<span class="spin">⚙️</span> Processing...';
        button.disabled = true;
    }

    // Simulate form submission
    setTimeout(() => {
        if (button) {
            button.innerHTML = button.getAttribute('data-original-text') || 'Submit';
            button.disabled = false;
        }
        showNotification('Success!', 'Action completed successfully', 'success');
    }, 1500);
}

// Modal functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        modal.style.animation = 'slideUp 0.3s ease';
    }
}

function closeModal(modal) {
    modal.style.animation = 'slideDown 0.3s ease';
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

// Notification system
function showNotification(title, message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type}`;
    notification.innerHTML = `
        <strong>${title}</strong>
        <p>${message}</p>
    `;
    
    const container = document.querySelector('.container') || document.body;
    container.insertBefore(notification, container.firstChild);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Tab switching
function switchTab(tabName) {
    const tabs = document.querySelectorAll('[data-tab-pane]');
    const buttons = document.querySelectorAll('[data-tab]');
    
    tabs.forEach(tab => {
        tab.style.display = 'none';
    });
    buttons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    const activeTab = document.querySelector(`[data-tab-pane="${tabName}"]`);
    if (activeTab) {
        activeTab.style.display = 'block';
        activeTab.style.animation = 'fadeInUp 0.3s ease';
    }
    
    const activeButton = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

// Search functionality
function performSearch(query, searchType) {
    console.log(`Searching in ${searchType}: ${query}`);
    // Implement search logic here
}

// Responsive navigation toggle
function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('mobile-open');
    }
}

// Smooth scroll
function smoothScroll(target) {
    const element = document.querySelector(target);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

// Date picker initialization (if needed)
function initializeDatePicker() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        input.setAttribute('min', today);
    });
}

// Currency formatter
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

// Budget calculation
function calculateBudgetUsage(spent, total) {
    return Math.round((spent / total) * 100);
}

// Progress bar update
function updateProgressBar(element, percentage) {
    if (element) {
        element.style.width = percentage + '%';
        element.textContent = percentage + '%';
    }
}

// Print functionality
function printPage() {
    window.print();
}

// Export to PDF (requires external library)
function exportToPDF(filename) {
    console.log(`Exporting to PDF: ${filename}`);
    // Implement PDF export here
}

// Local storage helper functions
function saveToLocalStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error('Error saving to localStorage:', error);
        return false;
    }
}

function getFromLocalStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Error reading from localStorage:', error);
        return null;
    }
}

// Utility: Format date
function formatDate(date) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(date).toLocaleDateString('en-US', options);
}

// Utility: Calculate trip duration
function calculateTripDuration(startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const duration = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    return duration;
}

// API calls simulation
async function fetchData(endpoint) {
    try {
        const response = await fetch(endpoint);
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error('Error fetching data:', error);
        return null;
    }
}

async function postData(endpoint, data) {
    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error('Error posting data:', error);
        return null;
    }
}

// Initialize on page load
window.addEventListener('load', function() {
    initializeDatePicker();
    console.log('Travel Roadmap Management System loaded successfully!');
});
