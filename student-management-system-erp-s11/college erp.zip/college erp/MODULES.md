# UniERP Module Map

This project is now split into small browser-loaded files so different people can work in parallel.

## File Ownership

1. `css/app.css` - All shared styling and layout rules.
1. `js/data.js` - Seed data, shared state, and common helpers.
2. `js/ui.js` - Modal and toast helpers.
3. `js/sidebar.js` - Sidebar menus and active nav state.
4. `js/auth.js` - Login and logout flow.
5. `js/router.js` - Page routing and title updates.
6. `js/shared.js` - Notices and profile pages shared by all roles.
7. `js/admin.js` - Admin dashboard, student/faculty/course management.
8. `js/faculty.js` - Faculty dashboard, attendance, marks, assignments, quizzes.
9. `js/student.js` - Student dashboard, academics, assignments, quizzes.
10. `js/app.js` - Bootstrapping and route registration.

## Team Split Suggestion

1. One person can own `data.js` and keep shared helpers stable.
2. One person can own `ui.js` and `router.js`.
3. One person can own `auth.js` and `sidebar.js`.
4. One person can own `shared.js`.
5. One person can own the admin work in `admin.js`.
6. Two people can split `faculty.js` by attendance/marks versus assignments/quizzes.
7. Two people can split `student.js` by dashboard/academics versus assignments/quizzes.

## How It Loads

The HTML page loads `css/app.css` in the head and the JS files in order at the bottom of `index.html`, so no build step is needed.
