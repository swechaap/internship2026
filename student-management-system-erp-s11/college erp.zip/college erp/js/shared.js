function renderNoticesPage(container, canPost) {
  container.innerHTML = `
  <div class="card">
    <div class="card-header">
      <h3>Notices and Announcements</h3>
      ${canPost ? '<button class="btn-sm btn-primary" onclick="postNotice()">+ Post Notice</button>' : ''}
    </div>
    <div class="card-body" id="noticeList">
      ${DB.notices.map(function (notice) {
        var colors = { exam: 'b-red', assignment: 'b-blue', general: 'b-gray' };
        return `<div style="border:1px solid var(--border);border-radius:10px;padding:18px;margin-bottom:12px;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
            <div style="font-weight:700;font-size:15px;">${notice.title}</div>
            <span class="badge ${colors[notice.type] || 'b-gray'}">${notice.type}</span>
          </div>
          <p style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:8px;">${notice.body}</p>
          <div style="font-size:11px;color:var(--muted);">Posted by ${notice.from} · ${notice.date}</div>
          ${canPost ? `<div style="margin-top:10px;"><button class="btn-sm btn-danger" onclick="deleteNotice('${notice.id}')">Delete</button></div>` : ''}
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

function postNotice() {
  openModal('Post New Notice', `
    <div class="form-row full"><div class="fg"><label>Title</label><input id="nn_title" placeholder="Notice title"/></div></div>
    <div class="form-row"><div class="fg"><label>Type</label><select id="nn_type"><option value="general">General</option><option value="exam">Exam</option><option value="assignment">Assignment</option></select></div>
    <div class="fg"><label>Date</label><input type="date" id="nn_date" value="${new Date().toISOString().split('T')[0]}"/></div></div>
    <div class="form-row full"><div class="fg"><label>Body</label><textarea id="nn_body" placeholder="Notice content..."></textarea></div></div>
  `, [
    { label: 'Cancel', cls: 'btn-sm btn-outline', action: closeModal },
    { label: 'Post', cls: 'btn-sm btn-primary', action: function () {
      var title = document.getElementById('nn_title').value.trim();
      if (!title) {
        toast('Enter notice title', 'red');
        return;
      }
      DB.notices.unshift({
        id: 'N' + Date.now(),
        title: title,
        body: document.getElementById('nn_body').value,
        date: document.getElementById('nn_date').value,
        from: currentUser.name,
        type: document.getElementById('nn_type').value,
      });
      closeModal();
      navigate(currentUser.role === 'admin' ? 'adminNotices' : 'facNotices');
      toast('Notice posted');
    } },
  ]);
}

function deleteNotice(id) {
  DB.notices = DB.notices.filter(function (notice) {
    return notice.id !== id;
  });
  navigate(currentUser.role === 'admin' ? 'adminNotices' : 'facNotices');
  toast('Notice removed');
}

function renderProfilePage(container, user, extras) {
  if (!extras) extras = [];
  var fields = [
    { label: 'Email', val: user.email },
    { label: 'Phone', val: user.phone || '—' },
    { label: 'Join Date', val: user.join || '—' },
  ]
    .concat(extras)
    .concat(user.subjects ? [{ label: 'Subjects', val: (user.subjects || []).join(', ') || '—' }] : [])
    .concat(user.dept && !extras.some(function (extra) { return extra.label === 'Department'; }) ? [{ label: 'Department', val: user.dept }] : []);

  container.innerHTML = `
  <div class="profile-header">
    <div class="profile-av">${user.name[0]}</div>
    <div class="profile-info">
      <h2>${user.name}</h2>
      <p>${user.id} · ${user.role ? user.role.toUpperCase() : ''}</p>
    </div>
  </div>
  <div class="card">
    <div class="card-header"><h3>Personal Information</h3>
      <button class="btn-sm btn-outline" onclick="editProfile()">Edit</button>
    </div>
    <div class="card-body">
      <div class="info-grid">
        ${fields.map(function (field) {
          return `<div class="info-item"><div class="ii-lbl">${field.label}</div><div class="ii-val">${field.val}</div></div>`;
        }).join('')}
      </div>
    </div>
  </div>`;
}

function editProfile() {
  openModal('Edit Profile', `
    <div class="form-row"><div class="fg"><label>Email</label><input id="ep_email" value="${currentUser.email || ''}"/></div>
    <div class="fg"><label>Phone</label><input id="ep_phone" value="${currentUser.phone || ''}"/></div></div>
    <div class="form-row"><div class="fg"><label>New Password</label><input type="password" id="ep_pass" placeholder="Leave blank to keep current"/></div></div>
  `, [
    { label: 'Cancel', cls: 'btn-sm btn-outline', action: closeModal },
    { label: 'Save', cls: 'btn-sm btn-primary', action: function () {
      currentUser.email = document.getElementById('ep_email').value;
      currentUser.phone = document.getElementById('ep_phone').value;
      var nextPassword = document.getElementById('ep_pass').value;
      if (nextPassword) currentUser.pass = nextPassword;
      closeModal();
      navigate(getProfilePage());
      toast('Profile updated');
    } },
  ]);
}
