function openModal(title, body, buttons) {
  if (!buttons) buttons = [];
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = body;
  var footer = document.getElementById('modalFooter');
  footer.innerHTML = '';
  buttons.forEach(function (button) {
    var el = document.createElement('button');
    el.className = button.cls;
    el.textContent = button.label;
    el.onclick = button.action;
    footer.appendChild(el);
  });
  document.getElementById('modalBg').classList.add('open');
}

function closeModal() {
  document.getElementById('modalBg').classList.remove('open');
}

function toast(msg, type) {
  if (!type) type = 'green';
  var colors = { green: '#16a34a', red: '#dc2626', amber: '#d97706' };
  var el = document.createElement('div');
  el.className = 'toast-msg';
  el.innerHTML = msg;
  el.style.borderLeft = '4px solid ' + (colors[type] || colors.green);
  document.getElementById('toast').appendChild(el);
  setTimeout(function () {
    el.remove();
  }, 3500);
}
