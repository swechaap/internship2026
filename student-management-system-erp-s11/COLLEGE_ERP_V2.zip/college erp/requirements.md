UniERP Detailed Requirements

1. Project Type
- Browser-based college management system.
- Static front-end application with a lightweight Node.js server.
- No Python/pip dependencies are required for the current codebase.

2. Runtime Requirements
- Node.js 18+ for the local server and API proxy.
- A modern browser with JavaScript enabled.
- Internet access is required only for NVIDIA AI requests.
- Localhost access must be available for the app and AI endpoints.

3. Startup Requirements
- Run the server with `npm start` or `node server.js`.
- Open `http://localhost:3000` in the browser.
- The app must load `index.html` from the project root.
- The AI Studio shortcut page must redirect to `index.html?page=aiHub`.

4. Environment Variables
- `PORT` controls the server port, default `3000`.
- `NVIDIA_API_KEY` is required for AI chat and attendance chat.
- `NVIDIA_ENDPOINT` is optional, defaulting to the NVIDIA chat completions endpoint.
- `AI_RATE_LIMIT` is optional and controls per-IP AI request throttling, default `20`.

5. Core Functional Requirements

5.1 Authentication
- Users must be able to sign in with an ID and password.
- The system must support admin, faculty, and student roles.
- Invalid credentials must be rejected with user feedback.
- Sign out must return the user to the login screen.

5.2 Admin Features
- View admin dashboard metrics.
- View and manage student records.
- View and manage faculty records.
- View and manage courses.
- View attendance summaries across students.
- View, post, and delete notices.
- View and edit the admin profile.

5.3 Faculty Features
- View faculty dashboard metrics.
- View assigned students.
- Record and save attendance.
- Enter and save marks.
- Create assignments.
- View assignment submissions.
- Update submission marks.
- Create quizzes.
- View quiz results.
- View and post notices.
- View and edit the faculty profile.

5.4 Student Features
- View student dashboard metrics.
- View attendance by subject.
- View marks and grades by subject.
- View assigned assignments.
- Upload assignment submissions.
- View quizzes.
- Take quizzes and submit answers.
- View notices.
- View and edit the student profile.

5.5 Shared Features
- Render role-based navigation menus.
- Support reusable modal dialogs.
- Support toast notifications.
- Support notice listing and deletion where permitted.
- Support profile viewing and editing.
- Support route-based page rendering and page titles.

6. AI Studio Requirements

6.1 Shared AI Requirements
- Provide an AI Studio page for all roles.
- Support role-aware AI tools and dashboards.
- Support report generation and local report history.
- Support report search and pagination.
- Support theme preference storage.
- Support PDF-style print export and CSV export.
- Support chat with the AI backend through `/api/ai/chat`.

6.2 Student AI Requirements
- Student performance tracker.
- Attendance predictor.
- Assignment assistant.
- Study plan generator.
- CGPA predictor.

6.3 Faculty AI Requirements
- Class performance analysis.
- Automatic question paper generator.
- Assignment evaluation assistant.

6.4 Admin AI Requirements
- Student risk detection.
- Resource utilization analytics.
- Feedback sentiment analysis.

6.5 Calendar and Chat Requirements
- Academic calendar search and AI-style calendar lookup.
- AI concierge chat for general help.
- Chat history must persist in browser storage.

7. Data Requirements
- The app must use in-memory sample data for demo usage.
- Student, faculty, attendance, marks, assignments, quizzes, notices, courses, and calendar data must be available in the seed dataset.
- Assignment submissions and quiz results must be stored in application state.
- AI reports, AI chat history, and AI theme preference must persist in `localStorage`.
- Data resets when the page reloads, except for browser-stored AI preferences/history.

8. Server Requirements
- Serve static files from the project root.
- Provide `GET /api/ai/chat` and `POST /api/ai/chat` behavior through the same handler logic as implemented.
- Provide `GET /api/attendance-chat` and `POST /api/attendance-chat` behavior through the same handler logic as implemented.
- Return JSON errors for API failures.
- Enforce request body size limits for AI requests.
- Apply basic per-IP AI rate limiting.
- Cache recent AI responses for short-term reuse.
- Set permissive CORS headers for local browser access.

9. Security and Validation Requirements
- Prevent path traversal when serving static files.
- Validate AI request payloads before sending them upstream.
- Reject overly large request bodies.
- Reject non-JSON AI request payloads.
- Escape user-provided text before rendering in HTML where applicable.
- Treat uploaded file previews as text-only when readable.

10. Browser and UI Requirements
- The app must be responsive on desktop and mobile viewports.
- The UI must include a sidebar, top bar, content area, modal layer, and toast area.
- The login screen must appear before authentication.
- The app must show the current date after login.
- The app must show the logged-in user avatar initial.

11. File and Module Requirements
- `index.html` must load all JS modules in the correct order.
- `css/app.css` must hold the shared styling.
- `js/data.js` must define seed data and shared helpers.
- `js/ui.js` must define modal and toast helpers.
- `js/sidebar.js` must define navigation menus.
- `js/auth.js` must define login and logout logic.
- `js/router.js` must define route registration and navigation.
- `js/shared.js` must define shared notices and profile pages.
- `js/admin.js` must define admin pages and CRUD actions.
- `js/faculty.js` must define faculty pages and management tools.
- `js/student.js` must define student pages and quiz/assignment flows.
- `js/ai.js` must define AI Studio functionality.
- `js/app.js` must bootstrap the application.

12. External Service Requirements
- NVIDIA AI access is required for live AI responses.
- `NVIDIA_API_KEY` must be configured for AI features to work.
- Network failures to the upstream AI provider must be handled gracefully.

13. Demo Account Requirements
- Admin demo account: `admin` / `admin123`
- Faculty demo account: `FAC001` / `faculty123`
- Faculty demo account: `FAC002` / `faculty123`
- Student demo account: `STU001` / `student123`
- Student demo account: `STU002` / `student123`
- Student demo account: `STU003` / `student123`

14. Operational Notes
- This project does not currently require `pip install -r requirements.txt`.
- If a Python backend is added later, a true pip dependency list can replace this document.
