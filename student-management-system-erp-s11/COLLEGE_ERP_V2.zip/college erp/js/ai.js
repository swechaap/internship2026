var AI_REPORT_STORAGE_PREFIX = 'unierp_ai_reports_';
var AI_CHAT_STORAGE_PREFIX = 'unierp_ai_chat_';
var AI_THEME_STORAGE_PREFIX = 'unierp_ai_theme_';

var aiStudioState = {
  exports: {},
  files: {},
  reportQuery: '',
  reportFilter: 'all',
  reportPage: 1,
  pageSize: 5,
  theme: 'light',
  loadingChat: false,
  skipSave: false,
};

var aiTopicMap = {
  'data structures': ['arrays and pointers', 'linked lists', 'trees and traversals', 'recursion patterns'],
  dbms: ['keys and constraints', 'normalization', 'joins and subqueries', 'transactions and recovery'],
  'digital circuits': ['boolean algebra', 'logic gates', 'k-maps', 'adders and flip-flops'],
  signals: ['sampling', 'fourier concepts', 'laplace basics', 'filters and transforms'],
  default: ['core concepts', 'problem solving', 'practice questions', 'revision cycles'],
};

var aiStopWords = {
  the: true, and: true, for: true, with: true, from: true, that: true, this: true, are: true, was: true, were: true,
  have: true, has: true, will: true, into: true, your: true, you: true, our: true, their: true, about: true, more: true,
  very: true, been: true, would: true, can: true, should: true, could: true, need: true, needed: true, good: true,
};

function escapeAiHtml(text) {
  return String(text == null ? '' : text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function aiClamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function aiRound(value) {
  return Math.round(value || 0);
}

function aiAverage(values) {
  var list = (values || []).filter(function (value) {
    return typeof value === 'number' && !isNaN(value);
  });
  if (!list.length) return 0;
  return list.reduce(function (sum, value) { return sum + value; }, 0) / list.length;
}

function aiNormalizeText(text) {
  return String(text || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function aiTokenize(text) {
  return aiNormalizeText(text).split(' ').filter(function (token) {
    return token && !aiStopWords[token] && token.length > 2;
  });
}

function aiGetRoleLabel(role) {
  return role === 'admin' ? 'Admin' : role === 'faculty' ? 'Faculty' : 'Student';
}

function aiGetLocalStorageKey(prefix) {
  return prefix + currentUser.id;
}

function loadAiReports() {
  try {
    var raw = window.localStorage.getItem(aiGetLocalStorageKey(AI_REPORT_STORAGE_PREFIX));
    var parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    return [];
  }
}

function saveAiReports(reports) {
  try {
    window.localStorage.setItem(aiGetLocalStorageKey(AI_REPORT_STORAGE_PREFIX), JSON.stringify(reports.slice(-80)));
  } catch (err) {
    // Ignore storage issues in private / restricted sessions.
  }
  DB.aiReports = reports.slice(-80);
}

function loadAiChatHistory() {
  try {
    var raw = window.localStorage.getItem(aiGetLocalStorageKey(AI_CHAT_STORAGE_PREFIX));
    var parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter(function (message) {
      return message && (message.role === 'user' || message.role === 'assistant') && typeof message.content === 'string';
    }) : [];
  } catch (err) {
    return [];
  }
}

function saveAiChatHistory(history) {
  try {
    window.localStorage.setItem(aiGetLocalStorageKey(AI_CHAT_STORAGE_PREFIX), JSON.stringify(history.slice(-40)));
  } catch (err) {
    // Ignore storage issues in private / restricted sessions.
  }
}

function loadAiPreferences() {
  try {
    var theme = window.localStorage.getItem(aiGetLocalStorageKey(AI_THEME_STORAGE_PREFIX));
    if (theme === 'dark') aiStudioState.theme = 'dark';
  } catch (err) {}
}

function saveAiPreferences() {
  try {
    window.localStorage.setItem(aiGetLocalStorageKey(AI_THEME_STORAGE_PREFIX), aiStudioState.theme);
  } catch (err) {}
}

function subjectTopics(subject) {
  var key = aiNormalizeText(subject);
  return aiTopicMap[key] || aiTopicMap.default;
}

function normalizeSubjectMarks(mark) {
  if (!mark) return 0;
  var weighted = (aiClamp(+mark.mid1 || 0, 0, 50) / 50) * 20 +
    (aiClamp(+mark.mid2 || 0, 0, 50) / 50) * 20 +
    (aiClamp(+mark.assign || 0, 0, 20) / 20) * 10 +
    (aiClamp(+mark.final || 0, 0, 100) / 100) * 50;
  return aiRound(weighted);
}

function buildSparkline(values, color) {
  var list = values || [];
  if (!list.length) return '<div class="ai-empty">No trend data</div>';

  var min = Math.min.apply(Math, list);
  var max = Math.max.apply(Math, list);
  var width = 240;
  var height = 68;
  var step = list.length > 1 ? width / (list.length - 1) : width;
  var points = list.map(function (value, index) {
    var normalized = max === min ? height / 2 : height - ((value - min) / (max - min)) * (height - 14) - 7;
    return [aiRound(index * step), aiRound(normalized)];
  });
  var path = points.map(function (point, index) {
    return (index === 0 ? 'M' : 'L') + point[0] + ' ' + point[1];
  }).join(' ');

  return [
    '<svg class="ai-spark" viewBox="0 0 ' + width + ' ' + height + '" preserveAspectRatio="none" role="img" aria-label="Trend chart">',
    '<path d="' + path + '" fill="none" stroke="' + (color || '#2563eb') + '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>',
    '</svg>',
  ].join('');
}

function renderAiRing(pct, label, color) {
  return [
    '<div class="ai-ring" style="--p:' + aiClamp(pct, 0, 100) + ';--c:' + (color || '#2563eb') + '">',
    '  <div class="ai-ring-inner">',
    '    <strong>' + aiRound(pct) + '%</strong>',
    '    <span>' + escapeAiHtml(label || 'Score') + '</span>',
    '  </div>',
    '</div>',
  ].join('');
}

function renderMetricStrip(metrics) {
  return '<div class="ai-metric-grid">' + (metrics || []).map(function (metric) {
    return [
      '<div class="ai-metric">',
      '<span class="ai-metric-label">' + escapeAiHtml(metric.label) + '</span>',
      '<strong>' + escapeAiHtml(metric.value) + '</strong>',
      metric.note ? '<em>' + escapeAiHtml(metric.note) + '</em>' : '',
      '</div>',
    ].join('');
  }).join('') + '</div>';
}

function saveAiReport(kind, title, summary, detail, tableRows) {
  if (aiStudioState.skipSave) return;
  var reports = loadAiReports();
  reports.unshift({
    id: 'AIR' + Date.now(),
    kind: kind,
    title: title,
    summary: summary,
    detail: detail,
    rows: tableRows || [],
    role: currentUser.role,
    user: currentUser.name,
    createdAt: new Date().toISOString(),
  });
  saveAiReports(reports);
  renderAiReports();
}

function storeAiExport(slot, title, html, csv) {
  aiStudioState.exports[slot] = {
    title: title,
    html: html,
    csv: csv,
  };
}

function downloadAiText(filename, content, mime) {
  var blob = new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
  var link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(function () {
    URL.revokeObjectURL(link.href);
  }, 1000);
}

function exportAiSlotPdf(slot) {
  var payload = aiStudioState.exports[slot];
  if (!payload) {
    toast('Generate a report before exporting', 'amber');
    return;
  }

  var win = window.open('', '_blank', 'width=1100,height=900');
  if (!win) {
    toast('Popup blocked. Allow popups to export PDF.', 'amber');
    return;
  }

  var doc = [
    '<!doctype html><html><head><title>' + escapeAiHtml(payload.title) + '</title>',
    '<style>body{font-family:Segoe UI,system-ui,sans-serif;padding:32px;color:#1e293b;} h1{margin:0 0 12px;} .meta{color:#64748b;margin-bottom:20px;} table{width:100%;border-collapse:collapse;margin-top:12px;} th,td{border:1px solid #e2e8f0;padding:8px 10px;text-align:left;font-size:13px;} th{background:#f8fafc;}</style>',
    '</head><body>',
    '<h1>' + escapeAiHtml(payload.title) + '</h1>',
    '<div class="meta">Generated by UniERP AI Studio</div>',
    payload.html || '',
    '</body></html>',
  ].join('');

  win.document.open();
  win.document.write(doc);
  win.document.close();
  setTimeout(function () {
    win.focus();
    win.print();
  }, 400);
}

function exportAiSlotExcel(slot) {
  var payload = aiStudioState.exports[slot];
  if (!payload || !payload.csv) {
    toast('No spreadsheet data is available for this report', 'amber');
    return;
  }
  downloadAiText((payload.title || 'ai-report').replace(/[^a-z0-9]+/gi, '_').toLowerCase() + '.csv', payload.csv, 'text/csv;charset=utf-8');
}

function setAiSlotHtml(slot, html) {
  var el = document.getElementById(slot);
  if (el) el.innerHTML = html;
}

function buildTopicBadges(subject) {
  return subjectTopics(subject).map(function (topic) {
    return '<span class="ai-chip">' + escapeAiHtml(topic) + '</span>';
  }).join('');
}

function getStudentPerformanceData(student) {
  var marks = DB.marks[student.id] || {};
  var attendance = DB.attendance[student.id] || {};
  var attendanceSummary = typeof buildAttendanceSummary === 'function'
    ? buildAttendanceSummary(attendance)
    : { subjects: [], overallPct: 0, weakest: null };

  var subjectRows = Object.keys(marks).map(function (subject) {
    var mark = marks[subject];
    var normalized = normalizeSubjectMarks(mark);
    var midTrend = (+mark.mid2 || 0) - (+mark.mid1 || 0);
    return {
      subject: subject,
      score: normalized,
      midTrend: midTrend,
      topics: subjectTopics(subject),
      mark: mark,
    };
  }).sort(function (a, b) {
    return a.score - b.score;
  });

  var weakest = subjectRows[0] || null;
  var averageScore = subjectRows.length ? aiRound(aiAverage(subjectRows.map(function (row) { return row.score; }))) : 0;
  var attendancePct = attendanceSummary.overallPct || 0;
  var confidence = averageScore >= 75 && attendancePct >= 80 ? 'High' : averageScore >= 60 ? 'Medium' : 'Low';
  var dailyHours = averageScore < 50 ? 2 : averageScore < 65 ? 1.5 : 1;
  var weakestTopics = weakest ? subjectTopics(weakest.subject) : subjectTopics('default');
  var motivator = averageScore < 50
    ? 'You are not far from a turnaround. A focused plan for the weakest subjects can lift the score quickly.'
    : averageScore < 70
      ? 'A few consistent study blocks and better revision timing can push this into the safe zone.'
      : 'You are in a stable range. Keep the current pace and tighten the weak spots.';

  return {
    attendanceSummary: attendanceSummary,
    subjectRows: subjectRows,
    weakest: weakest,
    averageScore: averageScore,
    confidence: confidence,
    dailyHours: dailyHours,
    weakestTopics: weakestTopics,
    motivator: motivator,
  };
}

function renderStudentPerformanceOutput() {
  var data = getStudentPerformanceData(currentUser);
  var weakest = data.weakest || { subject: 'No data', score: 0, midTrend: 0, topics: [] };
  var trendLabel = weakest.midTrend > 0 ? 'Improving' : weakest.midTrend < 0 ? 'Needs attention' : 'Stable';
  var chartValues = data.subjectRows.length ? data.subjectRows.map(function (row) { return row.score; }) : [0];
  var html = [
    renderMetricStrip([
      { label: 'Overall score', value: data.averageScore + '%', note: 'Normalized from internal and external marks' },
      { label: 'Weakest subject', value: weakest.subject, note: weakest.score + '% score' },
      { label: 'Confidence', value: data.confidence, note: 'Based on marks and attendance' },
    ]),
    '<div class="ai-insight-grid">',
    '  <div class="ai-card-mini">',
    '    <h4>Weakest subject</h4>',
    '    <strong>' + escapeAiHtml(weakest.subject) + '</strong>',
    '    <span>Current score: ' + weakest.score + '%</span>',
    '    <span>Trend: ' + escapeAiHtml(trendLabel) + '</span>',
    '  </div>',
    '  <div class="ai-card-mini">',
    '    <h4>Study plan</h4>',
    '    <strong>' + data.dailyHours + ' hours daily</strong>',
    '    <span>for ' + (data.averageScore < 50 ? '14' : data.averageScore < 65 ? '10' : '7') + ' days</span>',
    '    <span>Focus topics: ' + escapeAiHtml(data.weakestTopics.join(', ')) + '</span>',
    '  </div>',
    '  <div class="ai-card-mini">',
    '    <h4>Motivation</h4>',
    '    <strong>' + escapeAiHtml(data.confidence) + ' confidence</strong>',
    '    <span>' + escapeAiHtml(data.motivator) + '</span>',
    '  </div>',
    '</div>',
    '<div class="ai-flex-grid">',
    '  <div class="ai-ring-panel">' + renderAiRing(data.averageScore, 'Performance', '#2563eb') + '</div>',
    '  <div class="ai-chart-panel">' + buildSparkline(chartValues, '#0d9488') + '</div>',
    '</div>',
    '<div class="ai-topic-list">' + data.weakestTopics.map(function (topic) {
      return '<span class="ai-chip">' + escapeAiHtml(topic) + '</span>';
    }).join('') + '</div>',
  ].join('');

  setAiSlotHtml('studentPerformanceOut', html);
  storeAiExport(
    'studentPerformanceOut',
    'Student Performance Tracker',
    html,
    'Metric,Value\nOverall Score,' + data.averageScore + '%\nWeakest Subject,' + (weakest.subject || 'N/A') + '\nConfidence,' + data.confidence + '\n'
  );
  saveAiReport('student', 'Student Performance Tracker', data.averageScore + '% overall with ' + (weakest.subject || 'no weak subject') + ' as the weakest area.', data.motivator, data.subjectRows);
}

function renderAttendancePredictorOutput() {
  var total = aiClamp(+document.getElementById('ai_att_total').value || 0, 0, 9999);
  var present = aiClamp(+document.getElementById('ai_att_present').value || 0, 0, total);
  var remaining = aiClamp(+document.getElementById('ai_att_remaining').value || 0, 0, 9999);
  var required = Math.max(0, aiRound((0.75 * total - present) / 0.25));
  var shortage = Math.max(0, aiRound(0.75 * total - present));
  var canSkip = Math.max(0, aiRound((present - 0.75 * total) / 0.25));
  var currentPct = total ? aiRound((present / total) * 100) : 0;
  var risk = currentPct >= 80 ? 'Low' : currentPct >= 75 ? 'Borderline' : currentPct >= 60 ? 'Medium' : 'High';
  var predicted = total + remaining ? aiRound(((present + Math.min(remaining, required)) / (total + Math.min(remaining, required))) * 100) : currentPct;
  var progressValues = [currentPct, aiClamp(currentPct + 4, 0, 100), aiClamp(predicted, 0, 100)];

  var html = [
    renderMetricStrip([
      { label: 'Current attendance', value: currentPct + '%', note: present + '/' + total + ' classes attended' },
      { label: 'Shortage to 75%', value: shortage, note: 'classes needed if below threshold' },
      { label: 'Risk level', value: risk, note: remaining + ' classes remaining' },
    ]),
    '<div class="ai-flex-grid">',
    '  <div class="ai-ring-panel">' + renderAiRing(currentPct, 'Attendance', currentPct >= 75 ? '#16a34a' : currentPct >= 60 ? '#d97706' : '#dc2626') + '</div>',
    '  <div class="ai-chart-panel">' + buildSparkline(progressValues, currentPct >= 75 ? '#16a34a' : '#d97706') + '</div>',
    '</div>',
    '<div class="ai-insight-grid">',
    '  <div class="ai-card-mini"><h4>Classes required</h4><strong>' + required + '</strong><span>' + (required > 0 ? 'consecutive classes required to reach 75%' : 'You are already above the threshold') + '</span></div>',
    '  <div class="ai-card-mini"><h4>Maximum skip</h4><strong>' + canSkip + '</strong><span>' + (canSkip > 0 ? 'classes can still be skipped safely' : 'No buffer available right now') + '</span></div>',
    '  <div class="ai-card-mini"><h4>Prediction</h4><strong>' + predicted + '%</strong><span>if you attend the next ' + Math.min(remaining, required) + ' classes</span></div>',
    '</div>',
  ].join('');

  setAiSlotHtml('attendancePredictorOut', html);
  storeAiExport(
    'attendancePredictorOut',
    'Attendance Predictor',
    html,
    'Metric,Value\nCurrent Attendance,' + currentPct + '%\nClasses Required,' + required + '\nMaximum Skip,' + canSkip + '\nRisk,' + risk + '\n'
  );
  saveAiReport('student', 'Attendance Predictor', 'Current attendance is ' + currentPct + '% with ' + risk.toLowerCase() + ' risk.', 'Required classes to reach 75%: ' + required + '.', []);
}

function normalizeFilePreview(file, text) {
  var content = text || '';
  var snippets = content
    .replace(/\s+/g, ' ')
    .split('.')
    .map(function (part) { return part.trim(); })
    .filter(Boolean)
    .slice(0, 4);
  var keywords = aiTokenize(content).slice(0, 8);

  return {
    title: file.name,
    summary: snippets.length ? snippets.join('. ') + '.' : 'No readable text extracted from this file.',
    keywords: keywords,
    length: content.length,
    type: file.type || 'unknown',
  };
}

function readTextFile(file) {
  return new Promise(function (resolve) {
    var reader = new FileReader();
    reader.onload = function () { resolve(String(reader.result || '')); };
    reader.onerror = function () { resolve(''); };
    reader.readAsText(file);
  });
}

async function captureAiFiles(slot, input) {
  var list = Array.prototype.slice.call(input.files || []);
  var previews = [];

  for (var i = 0; i < list.length; i += 1) {
    var file = list[i];
    var readable = /text|csv|json|xml|html|markdown/.test(file.type) || /\.(txt|md|csv|json|html?|xml)$/i.test(file.name);
    var text = readable ? await readTextFile(file) : '';
    previews.push(normalizeFilePreview(file, text));
  }

  aiStudioState.files[slot] = previews;
  renderFilePreview(slot);
}

function renderFilePreview(slot) {
  var el = document.getElementById(slot);
  if (!el) return;

  var files = aiStudioState.files[slot] || [];
  if (!files.length) {
    el.innerHTML = '<div class="ai-empty">No files uploaded yet.</div>';
    return;
  }

  el.innerHTML = files.map(function (file, index) {
    return [
      '<div class="ai-file-item">',
      '  <strong>' + (index + 1) + '. ' + escapeAiHtml(file.title) + '</strong>',
      '  <span>' + escapeAiHtml(file.type) + ' • ' + file.length + ' chars extracted</span>',
      '  <p>' + escapeAiHtml(file.summary) + '</p>',
      '  <div class="ai-chip-row">' + (file.keywords || []).map(function (keyword) {
        return '<span class="ai-chip">' + escapeAiHtml(keyword) + '</span>';
      }).join('') + '</div>',
      '</div>',
    ].join('');
  }).join('');
}

async function renderAssignmentAssistantOutput() {
  var files = aiStudioState.files.assignmentUploads || [];
  var notes = document.getElementById('assignmentAssistantPrompt').value.trim();
  var summaries = [];
  var allText = [];

  for (var i = 0; i < files.length; i += 1) {
    summaries.push(files[i].title + ': ' + files[i].summary);
    allText.push(files[i].summary);
  }

  if (!files.length) {
    setAiSlotHtml('assignmentAssistantOut', '<div class="ai-empty">Upload one or more PDF, DOCX, TXT, or CSV files to generate a summary.</div>');
    return;
  }

  var joined = allText.join(' ');
  var words = aiTokenize(joined);
  var topKeywords = [];
  words.forEach(function (word) {
    if (topKeywords.indexOf(word) === -1) topKeywords.push(word);
  });

  var flashcards = topKeywords.slice(0, 5).map(function (word) {
    return '<div class="ai-card-mini"><h4>Flashcard</h4><strong>' + escapeAiHtml(word) + '</strong><span>Explain the concept, give an example, and note the formula or rule.</span></div>';
  }).join('');

  var questions = topKeywords.slice(0, 5).map(function (word) {
    return '<li>' + escapeAiHtml('How does ' + word + ' appear in the assignment?') + '</li>';
  }).join('');

  var html = [
    renderMetricStrip([
      { label: 'Files processed', value: String(files.length), note: 'Multiple uploads supported' },
      { label: 'Extracted keywords', value: String(topKeywords.length), note: 'Auto-generated from uploaded text' },
      { label: 'Difficulty', value: notes ? 'User focused' : 'Balanced', note: 'Use notes to steer the prompt' },
    ]),
    '<div class="ai-summary-box"><strong>Summary</strong><p>' + escapeAiHtml(summaries.join(' ')) + '</p></div>',
    '<div class="ai-chip-row">' + topKeywords.slice(0, 12).map(function (keyword) { return '<span class="ai-chip">' + escapeAiHtml(keyword) + '</span>'; }).join('') + '</div>',
    '<div class="ai-insight-grid">',
    '  <div class="ai-card-mini"><h4>Study notes</h4><strong>Key points</strong><span>' + escapeAiHtml(topKeywords.slice(0, 4).join(', ') || 'No keywords detected') + '</span></div>',
    '  <div class="ai-card-mini"><h4>Revision focus</h4><strong>Important questions</strong><ul class="ai-list">' + questions + '</ul></div>',
    '  <div class="ai-card-mini"><h4>Revision helpers</h4><strong>Flashcards</strong><span>Use the cards below to revise quickly.</span></div>',
    '</div>',
    '<div class="ai-insight-grid">' + flashcards + '</div>',
  ].join('');

  setAiSlotHtml('assignmentAssistantOut', html);
  storeAiExport('assignmentAssistantOut', 'Assignment Assistant', html, 'File,Summary\n' + files.map(function (file) {
    return '"' + file.title.replace(/"/g, '""') + '","' + file.summary.replace(/"/g, '""') + '"';
  }).join('\n'));
  saveAiReport('student', 'Assignment Assistant', 'Processed ' + files.length + ' file(s).', 'Keywords: ' + topKeywords.slice(0, 8).join(', '), files);
}

function generateStudyPlan() {
  var examDate = document.getElementById('studyExamDate').value;
  var hours = aiClamp(+document.getElementById('studyHours').value || 2, 1, 12);
  var weakSubjects = document.getElementById('studyWeakSubjects').value.split(',').map(function (item) {
    return item.trim();
  }).filter(Boolean);
  var timetable = document.getElementById('studyTimetable').value.trim();
  var days = aiClamp(+document.getElementById('studyDays').value || 7, 3, 30);
  var subjects = weakSubjects.length ? weakSubjects : subjectTopics('default');
  var rows = [];

  for (var i = 0; i < days; i += 1) {
    var subject = subjects[i % subjects.length];
    rows.push({
      day: i + 1,
      focus: subject,
      block1: 'Concept review',
      block2: 'Practice questions',
      block3: 'Revision break',
    });
  }

  var html = [
    renderMetricStrip([
      { label: 'Exam date', value: examDate || 'Not set', note: 'Plan generated backwards from this date' },
      { label: 'Study hours', value: hours + ' hrs/day', note: 'Available focused hours' },
      { label: 'Priority subjects', value: String(subjects.length), note: timetable ? 'Timetable considered' : 'No timetable entered' },
    ]),
    '<div class="ai-plan-grid">' + rows.map(function (row) {
      return [
        '<div class="ai-plan-row">',
        '  <strong>Day ' + row.day + ' • ' + escapeAiHtml(row.focus) + '</strong>',
        '  <span>' + row.block1 + '</span>',
        '  <span>' + row.block2 + '</span>',
        '  <span>' + row.block3 + '</span>',
        '</div>',
      ].join('');
    }).join('') + '</div>',
    '<div class="ai-summary-box"><strong>Schedule notes</strong><p>Break the plan into ' + hours + '-hour blocks, keep 10-minute breaks between sessions, and protect the last two days for revision and mock tests.</p></div>',
  ].join('');

  setAiSlotHtml('studyPlannerOut', html);
  storeAiExport('studyPlannerOut', 'AI Study Planner', html, rows.map(function (row) {
    return ['Day ' + row.day, row.focus, row.block1, row.block2, row.block3].join(',');
  }).join('\n'));
  saveAiReport('student', 'AI Study Planner', 'Created a ' + days + '-day study plan for ' + subjects.join(', ') + '.', timetable || 'No timetable entered', rows);
}

function predictCgpa() {
  var currentSgpa = aiClamp(+document.getElementById('cgpaCurrentSgpa').value || 0, 0, 10);
  var previousCgpa = aiClamp(+document.getElementById('cgpaPreviousCgpa').value || currentSgpa, 0, 10);
  var completedCredits = aiClamp(+document.getElementById('cgpaCompletedCredits').value || 0, 0, 500);
  var remainingCredits = aiClamp(+document.getElementById('cgpaRemainingCredits').value || 0, 0, 500);
  var targetCgpa = aiClamp(+document.getElementById('cgpaTarget').value || 8, 0, 10);
  var expectedSgpa = aiRound((currentSgpa * 0.6 + previousCgpa * 0.4) * 10) / 10;
  var bestCase = (previousCgpa * completedCredits + 10 * remainingCredits) / (completedCredits + remainingCredits || 1);
  var worstCase = (previousCgpa * completedCredits + 6 * remainingCredits) / (completedCredits + remainingCredits || 1);
  var expectedCgpa = (previousCgpa * completedCredits + expectedSgpa * remainingCredits) / (completedCredits + remainingCredits || 1);
  var requiredAverage = (targetCgpa * (completedCredits + remainingCredits) - previousCgpa * completedCredits) / (remainingCredits || 1);

  var html = [
    renderMetricStrip([
      { label: 'Expected SGPA', value: expectedSgpa.toFixed(1), note: 'Based on current trajectory' },
      { label: 'Expected CGPA', value: expectedCgpa.toFixed(2), note: 'Weighted by credit counts' },
      { label: 'Needed for target', value: requiredAverage.toFixed(2), note: 'Average SGPA needed this term' },
    ]),
    '<div class="ai-flex-grid">',
    '  <div class="ai-ring-panel">' + renderAiRing(aiClamp(expectedCgpa * 10, 0, 100), 'CGPA', '#0d9488') + '</div>',
    '  <div class="ai-card-mini">',
    '    <h4>Range</h4>',
    '    <strong>Best case ' + bestCase.toFixed(2) + '</strong>',
    '    <span>Worst case ' + worstCase.toFixed(2) + '</span>',
    '    <span>Target ' + targetCgpa.toFixed(2) + '</span>',
    '  </div>',
    '</div>',
  ].join('');

  setAiSlotHtml('cgpaPredictorOut', html);
  storeAiExport('cgpaPredictorOut', 'CGPA Predictor', html, 'Metric,Value\nExpected SGPA,' + expectedSgpa.toFixed(1) + '\nExpected CGPA,' + expectedCgpa.toFixed(2) + '\nBest Case,' + bestCase.toFixed(2) + '\nWorst Case,' + worstCase.toFixed(2) + '\n');
  saveAiReport('student', 'CGPA Predictor', 'Projected CGPA is ' + expectedCgpa.toFixed(2) + '.', 'Target requires ' + requiredAverage.toFixed(2) + ' SGPA in remaining subjects.', []);
}

function getFacultyClassRows(subject) {
  var dept = subjectDept(subject);
  return DB.students.filter(function (student) {
    return student.dept === dept;
  }).map(function (student) {
    var mark = (DB.marks[student.id] || {})[subject] || { mid1: 0, mid2: 0, assign: 0, final: 0 };
    var score = normalizeSubjectMarks(mark);
    var attendance = DB.attendance[student.id] || {};
    var summary = typeof buildAttendanceSummary === 'function' ? buildAttendanceSummary(attendance) : { overallPct: 0 };
    return {
      student: student,
      score: score,
      attendance: summary.overallPct || 0,
    };
  });
}

function analyzeFacultyClass() {
  var subject = document.getElementById('facultySubjectSelect').value;
  var rows = getFacultyClassRows(subject);
  var avgScore = aiRound(aiAverage(rows.map(function (row) { return row.score; })));
  var highest = rows.slice().sort(function (a, b) { return b.score - a.score; })[0] || null;
  var lowest = rows.slice().sort(function (a, b) { return a.score - b.score; })[0] || null;
  var passCount = rows.filter(function (row) { return row.score >= 60; }).length;
  var passPct = rows.length ? aiRound((passCount / rows.length) * 100) : 0;
  var weakTopics = subjectTopics(subject).slice(0, 4);
  var heatCells = rows.map(function (row) {
    var tone = row.score >= 75 ? 'ai-heat-good' : row.score >= 60 ? 'ai-heat-mid' : 'ai-heat-bad';
    return '<div class="ai-heat-cell ' + tone + '">' + escapeAiHtml(row.student.name.split(' ')[0]) + '<span>' + row.score + '%</span></div>';
  }).join('');

  var html = [
    renderMetricStrip([
      { label: 'Average score', value: avgScore + '%', note: rows.length + ' students analyzed' },
      { label: 'Highest', value: highest ? highest.student.name : 'N/A', note: highest ? highest.score + '%' : 'No data' },
      { label: 'Pass rate', value: passPct + '%', note: lowPassNote(passPct) },
    ]),
    '<div class="ai-flex-grid">',
    '  <div class="ai-ring-panel">' + renderAiRing(passPct, 'Pass rate', passPct >= 70 ? '#16a34a' : passPct >= 50 ? '#d97706' : '#dc2626') + '</div>',
    '  <div class="ai-card-mini">',
    '    <h4>Class heatmap</h4>',
    '    <div class="ai-heat-grid">' + heatCells + '</div>',
    '  </div>',
    '</div>',
    '<div class="ai-insight-grid">',
    '  <div class="ai-card-mini"><h4>Weak topics</h4><strong>' + escapeAiHtml(weakTopics.join(', ')) + '</strong><span>These are the best candidates for revision classes.</span></div>',
    '  <div class="ai-card-mini"><h4>Intervention</h4><strong>' + escapeAiHtml(buildInterventionText(passPct)) + '</strong><span>Use targeted practice and quick remedials.</span></div>',
    '  <div class="ai-card-mini"><h4>Trend</h4>' + buildSparkline(rows.map(function (row) { return row.score; }), '#2563eb') + '</div>',
    '</div>',
  ].join('');

  setAiSlotHtml('facultyAnalysisOut', html);
  storeAiExport('facultyAnalysisOut', 'Class Performance Analysis', html, 'Student,Score,Attendance\n' + rows.map(function (row) {
    return '"' + row.student.name.replace(/"/g, '""') + '",' + row.score + ',' + row.attendance;
  }).join('\n'));
  saveAiReport('faculty', 'Class Performance Analysis', subject + ' average at ' + avgScore + '% with ' + passPct + '% pass rate.', buildInterventionText(passPct), rows);
}

function lowPassNote(passPct) {
  if (passPct >= 80) return 'Strong standing';
  if (passPct >= 65) return 'Needs attention';
  return 'Immediate follow-up recommended';
}

function buildInterventionText(passPct) {
  if (passPct >= 80) return 'Continue enrichment and advanced practice.';
  if (passPct >= 65) return 'Offer one remedial session and weekly practice sheets.';
  return 'Plan an intervention batch, pair mentoring, and quick follow-up tests.';
}

function generateQuestionPaper() {
  var subject = document.getElementById('qpSubject').value.trim();
  var unit = document.getElementById('qpUnit').value.trim();
  var topics = document.getElementById('qpTopics').value.split(',').map(function (item) { return item.trim(); }).filter(Boolean);
  var difficulty = document.getElementById('qpDifficulty').value;
  var marks = aiClamp(+document.getElementById('qpMarks').value || 50, 20, 100);
  var topicList = topics.length ? topics : subjectTopics(subject);
  var sectionA = topicList.slice(0, 2).map(function (topic, index) {
    return (index + 1) + '. Define ' + topic + ' and mention one example.';
  }).join('<br>');
  var sectionB = topicList.slice(0, 3).map(function (topic) {
    return '<li>Explain ' + topic + ' with a neat diagram and Bloom level: Understand</li>';
  }).join('');
  var sectionC = topicList.slice(0, 2).map(function (topic) {
    return '<li>' + topic + ': apply the concept to a real campus scenario. Bloom level: Apply</li>';
  }).join('');
  var csvRows = [
    'Section,Question,Bloom,Difficulty',
    'A,"Define ' + topicList[0] + '",Remember,' + difficulty,
    'B,"Explain ' + topicList[1 % topicList.length] + ' with examples",Understand,' + difficulty,
    'C,"Apply ' + topicList[0] + ' in a real scenario",Apply,' + difficulty,
  ].join('\n');

  var html = [
    renderMetricStrip([
      { label: 'Subject', value: subject || 'Untitled', note: unit ? 'Unit ' + unit : 'No unit entered' },
      { label: 'Marks', value: String(marks), note: difficulty + ' level paper' },
      { label: 'Topics', value: String(topicList.length), note: 'Bloom tags included' },
    ]),
    '<div class="ai-paper">',
    '  <div class="ai-paper-head">',
    '    <strong>Section A</strong><span>Short answers</span>',
    '    <p>' + sectionA + '</p>',
    '  </div>',
    '  <div class="ai-paper-head">',
    '    <strong>Section B</strong><span>Medium answers</span>',
    '    <ul>' + sectionB + '</ul>',
    '  </div>',
    '  <div class="ai-paper-head">',
    '    <strong>Section C</strong><span>Long answers</span>',
    '    <ul>' + sectionC + '</ul>',
    '  </div>',
    '</div>',
    '<div class="ai-summary-box"><strong>Question paper notes</strong><p>Difficulty: ' + escapeAiHtml(difficulty) + '. The generated paper balances recall, explanation, and application questions while tagging each item for Bloom taxonomy.</p></div>',
  ].join('');

  setAiSlotHtml('questionPaperOut', html);
  storeAiExport('questionPaperOut', 'Question Paper Generator', html, csvRows);
  saveAiReport('faculty', 'Question Paper Generator', subject + ' paper generated for unit ' + unit + '.', difficulty + ' difficulty with ' + topicList.length + ' topics.', []);
}

async function evaluateAssignments() {
  var files = aiStudioState.files.evaluationUploads || [];
  if (!files.length) {
    setAiSlotHtml('assignmentEvaluationOut', '<div class="ai-empty">Upload student submissions first.</div>');
    return;
  }

  var pairwise = [];
  for (var i = 0; i < files.length; i += 1) {
    for (var j = i + 1; j < files.length; j += 1) {
      var a = aiTokenize(files[i].summary);
      var b = aiTokenize(files[j].summary);
      var shared = a.filter(function (token) { return b.indexOf(token) !== -1; });
      var similarity = aiRound((shared.length / Math.max(a.length || 1, b.length || 1)) * 100);
      if (similarity >= 40) {
        pairwise.push(files[i].title + ' / ' + files[j].title + ' - ' + similarity + '%');
      }
    }
  }

  var remarks = files.map(function (file) {
    var score = aiClamp(file.length > 800 ? 9 : file.length > 300 ? 7 : 5, 1, 10);
    var mark = aiRound(score * 10);
    return {
      file: file.title,
      marks: mark,
      notes: file.keywords.slice(0, 5).join(', ') || 'Review for missing detail',
    };
  });

  var html = [
    renderMetricStrip([
      { label: 'Submissions', value: String(files.length), note: 'Multiple uploads analyzed' },
      { label: 'Similarities', value: String(pairwise.length), note: 'Basic overlap detector' },
      { label: 'Average marks', value: aiRound(aiAverage(remarks.map(function (item) { return item.marks; }))) + '/100', note: 'Suggested only' },
    ]),
    '<div class="ai-list-card">',
    '  <h4>Feedback comments</h4>',
    '  <ul class="ai-list">' + remarks.map(function (item) {
      return '<li><strong>' + escapeAiHtml(item.file) + ':</strong> Suggested ' + item.marks + '/100. ' + escapeAiHtml(item.notes) + '.</li>';
    }).join('') + '</ul>',
    '</div>',
    '<div class="ai-list-card">',
    '  <h4>Plagiarism watch</h4>',
    pairwise.length ? '<ul class="ai-list">' + pairwise.map(function (line) { return '<li>' + escapeAiHtml(line) + '</li>'; }).join('') + '</ul>' : '<p>No suspicious overlap found among the uploaded drafts.</p>',
    '</div>',
  ].join('');

  setAiSlotHtml('assignmentEvaluationOut', html);
  storeAiExport('assignmentEvaluationOut', 'Assignment Evaluation Assistant', html, 'File,Marks,Notes\n' + remarks.map(function (item) {
    return '"' + item.file.replace(/"/g, '""') + '",' + item.marks + ',"' + item.notes.replace(/"/g, '""') + '"';
  }).join('\n'));
  saveAiReport('faculty', 'Assignment Evaluation Assistant', 'Processed ' + files.length + ' submissions.', pairwise.length + ' suspicious overlaps detected.', remarks);
}

function analyzeStudentRisk() {
  var rows = DB.students.map(function (student) {
    var attendance = DB.attendance[student.id] || {};
    var summary = typeof buildAttendanceSummary === 'function' ? buildAttendanceSummary(attendance) : { overallPct: 0 };
    var marks = DB.marks[student.id] || {};
    var scores = Object.keys(marks).map(function (subject) {
      return normalizeSubjectMarks(marks[subject]);
    });
    var avgScore = aiAverage(scores);
    var risk = aiRound(aiClamp((75 - (summary.overallPct || 0)) * 1.5 + (65 - avgScore) * 1.2, 0, 100));
    var level = risk >= 70 ? 'Critical' : risk >= 45 ? 'High' : risk >= 25 ? 'Medium' : 'Low';
    var reason = [];
    if ((summary.overallPct || 0) < 75) reason.push('attendance below 75%');
    if (avgScore < 60) reason.push('marks trending low');
    if (student.backlogs) reason.push('backlogs pending');
    return {
      student: student,
      attendance: summary.overallPct || 0,
      marks: aiRound(avgScore),
      risk: risk,
      level: level,
      reason: reason.length ? reason.join(', ') : 'stable academic profile',
      action: risk >= 70 ? 'Immediate mentor review' : risk >= 45 ? 'Parent outreach and remedial plan' : 'Monitor weekly',
    };
  }).sort(function (a, b) {
    return b.risk - a.risk;
  });

  var html = [
    renderMetricStrip([
      { label: 'At risk', value: String(rows.filter(function (row) { return row.level === 'Critical' || row.level === 'High'; }).length), note: 'Prioritized by score' },
      { label: 'Critical', value: String(rows.filter(function (row) { return row.level === 'Critical'; }).length), note: 'Needs immediate action' },
      { label: 'Average risk', value: aiRound(aiAverage(rows.map(function (row) { return row.risk; }))) + '/100', note: 'Combined score' },
    ]),
    '<table class="tbl"><thead><tr><th>Student</th><th>Risk</th><th>Reason</th><th>Intervention</th></tr></thead><tbody>' + rows.map(function (row) {
      return '<tr><td>' + escapeAiHtml(row.student.name) + '</td><td><span class="badge ' + (row.level === 'Critical' ? 'b-red' : row.level === 'High' ? 'b-amber' : row.level === 'Medium' ? 'b-blue' : 'b-green') + '">' + row.level + ' (' + row.risk + ')</span></td><td>' + escapeAiHtml(row.reason) + '</td><td>' + escapeAiHtml(row.action) + '</td></tr>';
    }).join('') + '</tbody></table>',
  ].join('');

  setAiSlotHtml('adminRiskOut', html);
  storeAiExport('adminRiskOut', 'Student Risk Detection', html, 'Student,Risk,Reason,Intervention\n' + rows.map(function (row) {
    return '"' + row.student.name.replace(/"/g, '""') + '",' + row.risk + ',"' + row.reason.replace(/"/g, '""') + '","' + row.action.replace(/"/g, '""') + '"';
  }).join('\n'));
  saveAiReport('admin', 'Student Risk Detection', rows[0] ? rows[0].student.name + ' is the highest risk student.' : 'No student risk data found.', 'Average risk score ' + aiRound(aiAverage(rows.map(function (row) { return row.risk; }))) + '.', rows);
}

function analyzeResources() {
  var rows = DB.resourceUsage.map(function (resource) {
    var unused = 100 - resource.usage;
    return {
      resource: resource,
      unused: unused,
      pressure: resource.usage >= 85 ? 'Peak' : resource.usage >= 65 ? 'Balanced' : 'Available',
    };
  });
  var html = [
    renderMetricStrip([
      { label: 'Average utilization', value: aiRound(aiAverage(rows.map(function (row) { return row.resource.usage; }))) + '%', note: 'Across classrooms and labs' },
      { label: 'Peak usage', value: String(rows.filter(function (row) { return row.resource.usage >= 85; }).length), note: 'Need capacity planning' },
      { label: 'Free capacity', value: String(aiRound(aiAverage(rows.map(function (row) { return row.unused; })))) + '%', note: 'Underused resources' },
    ]),
    '<table class="tbl"><thead><tr><th>Resource</th><th>Type</th><th>Usage</th><th>Peak Hours</th><th>Advice</th></tr></thead><tbody>' + rows.map(function (row) {
      return '<tr><td>' + escapeAiHtml(row.resource.name) + '</td><td>' + escapeAiHtml(row.resource.type) + '</td><td><div class="ai-progress"><span style="width:' + row.resource.usage + '%"></span></div><small>' + row.resource.usage + '%</small></td><td>' + escapeAiHtml(row.resource.peak) + '</td><td>' + escapeAiHtml(row.resource.remarks) + '</td></tr>';
    }).join('') + '</tbody></table>',
  ].join('');

  setAiSlotHtml('adminResourcesOut', html);
  storeAiExport('adminResourcesOut', 'Resource Utilization Analytics', html, 'Resource,Usage,Peak Hours,Advice\n' + rows.map(function (row) {
    return '"' + row.resource.name.replace(/"/g, '""') + '",' + row.resource.usage + ',"' + row.resource.peak.replace(/"/g, '""') + '","' + row.resource.remarks.replace(/"/g, '""') + '"';
  }).join('\n'));
  saveAiReport('admin', 'Resource Utilization Analytics', 'Average utilization at ' + aiRound(aiAverage(rows.map(function (row) { return row.resource.usage; }))) + '%.', 'Peak demand resources: ' + rows.filter(function (row) { return row.resource.usage >= 85; }).map(function (row) { return row.resource.name; }).join(', '), rows);
}

function analyzeFeedback() {
  var rows = DB.feedbackForms.map(function (entry) {
    var tokens = aiTokenize(entry.text);
    var positiveWords = ['good', 'great', 'clear', 'responsive', 'excellent', 'useful', 'helpful'];
    var negativeWords = ['poor', 'slow', 'unstable', 'crowded', 'issue', 'problem', 'needs', 'lack'];
    var pos = tokens.filter(function (token) { return positiveWords.indexOf(token) !== -1; }).length;
    var neg = tokens.filter(function (token) { return negativeWords.indexOf(token) !== -1; }).length;
    var score = pos > neg ? 1 : neg > pos ? -1 : 0;
    return {
      entry: entry,
      score: score,
      tokens: tokens,
    };
  });
  var positive = rows.filter(function (row) { return row.score > 0; }).length;
  var negative = rows.filter(function (row) { return row.score < 0; }).length;
  var neutral = rows.length - positive - negative;
  var keywordCounts = {};
  rows.forEach(function (row) {
    row.tokens.forEach(function (token) {
      keywordCounts[token] = (keywordCounts[token] || 0) + 1;
    });
  });
  var topKeywords = Object.keys(keywordCounts).sort(function (a, b) {
    return keywordCounts[b] - keywordCounts[a];
  }).slice(0, 6);

  var html = [
    renderMetricStrip([
      { label: 'Positive', value: positive + '%', note: 'Compared against total feedback items' },
      { label: 'Neutral', value: neutral + '%', note: 'Neither strongly positive nor negative' },
      { label: 'Negative', value: negative + '%', note: 'Needs attention' },
    ]),
    '<div class="ai-flex-grid">',
    '  <div class="ai-ring-panel">' + renderAiRing(rows.length ? aiRound((positive / rows.length) * 100) : 0, 'Positive', '#16a34a') + '</div>',
    '  <div class="ai-card-mini"><h4>Common complaints</h4><span>' + escapeAiHtml(topKeywords.join(', ')) + '</span><div class="ai-chip-row">' + topKeywords.map(function (keyword) { return '<span class="ai-chip">' + escapeAiHtml(keyword) + '</span>'; }).join('') + '</div></div>',
    '</div>',
    '<table class="tbl"><thead><tr><th>Department</th><th>Sentiment</th><th>Snippet</th></tr></thead><tbody>' + rows.map(function (row) {
      var label = row.score > 0 ? 'Positive' : row.score < 0 ? 'Negative' : 'Neutral';
      var tone = row.score > 0 ? 'b-green' : row.score < 0 ? 'b-red' : 'b-gray';
      return '<tr><td>' + escapeAiHtml(row.entry.department) + '</td><td><span class="badge ' + tone + '">' + label + '</span></td><td>' + escapeAiHtml(row.entry.text) + '</td></tr>';
    }).join('') + '</tbody></table>',
  ].join('');

  setAiSlotHtml('adminFeedbackOut', html);
  storeAiExport('adminFeedbackOut', 'Feedback Sentiment Analysis', html, 'Department,Sentiment,Snippet\n' + rows.map(function (row) {
    var label = row.score > 0 ? 'Positive' : row.score < 0 ? 'Negative' : 'Neutral';
    return '"' + row.entry.department.replace(/"/g, '""') + '",' + label + ',"' + row.entry.text.replace(/"/g, '""') + '"';
  }).join('\n'));
  saveAiReport('admin', 'Feedback Sentiment Analysis', positive + ' positive, ' + neutral + ' neutral, ' + negative + ' negative.', 'Keywords: ' + topKeywords.join(', '), rows);
}

function buildCalendarAnswer(query) {
  var text = aiNormalizeText(query);
  var entries = DB.academicCalendar.slice().sort(function (a, b) {
    return String(a.date).localeCompare(String(b.date));
  });
  if (!entries.length) return 'No calendar entries are available yet.';

  if (text.indexOf('next holiday') !== -1 || text.indexOf('holiday') !== -1) {
    var holiday = entries.find(function (entry) {
      return entry.category === 'holiday';
    });
    if (holiday) return 'The next holiday is ' + holiday.title + ' on ' + holiday.date + '.';
  }

  if (text.indexOf('last working day') !== -1) {
    var lastDay = entries.slice().reverse().find(function (entry) {
      return text.indexOf('last working day') !== -1 ? entry.title.toLowerCase().indexOf('last working day') !== -1 : false;
    });
    if (lastDay) return 'The last working day is ' + lastDay.date + '.';
  }

  if (text.indexOf('internal exam 2') !== -1 || text.indexOf('internal 2') !== -1) {
    var internal2 = entries.find(function (entry) {
      return entry.title.toLowerCase().indexOf('internal exam 2') !== -1;
    });
    if (internal2) return internal2.title + ' is scheduled for ' + internal2.date + '.';
  }

  if (text.indexOf('semester exams') !== -1 || text.indexOf('exams start') !== -1) {
    var exam = entries.find(function (entry) {
      return entry.category === 'exam' && entry.title.toLowerCase().indexOf('end semester') !== -1;
    });
    if (exam) return 'Semester exams begin on ' + exam.date + '.';
  }

  var match = entries.filter(function (entry) {
    var haystack = aiNormalizeText(entry.title + ' ' + entry.details + ' ' + (entry.keywords || []).join(' '));
    return text.split(' ').some(function (token) {
      return token && haystack.indexOf(token) !== -1;
    });
  });

  if (match.length) {
    return match.slice(0, 3).map(function (entry) {
      return entry.date + ' - ' + entry.title + ': ' + entry.details;
    }).join('\n');
  }

  return 'I could not find an exact match. Try asking about holidays, internal exams, last working day, or semester exams.';
}

function renderCalendarSection(persist) {
  var query = document.getElementById('calendarSearch').value.trim();
  var answer = query ? buildCalendarAnswer(query) : 'Ask a question such as "When is the next holiday?" or "Show timetable for Semester 4."';
  var results = DB.academicCalendar.filter(function (entry) {
    var haystack = aiNormalizeText(entry.title + ' ' + entry.details + ' ' + (entry.keywords || []).join(' ') + ' ' + entry.date);
    return !query || query.split(/\s+/).some(function (term) {
      return term && haystack.indexOf(term) !== -1;
    });
  }).slice(0, 6);

  var html = [
    renderMetricStrip([
      { label: 'Calendar entries', value: String(DB.academicCalendar.length), note: 'Semantic search enabled' },
      { label: 'Visible results', value: String(results.length), note: 'Matches your question' },
      { label: 'RAG ready', value: 'Yes', note: 'Source text is highlighted below' },
    ]),
    '<div class="ai-summary-box"><strong>Answer</strong><p>' + escapeAiHtml(answer) + '</p></div>',
    '<div class="ai-calendar-list">' + results.map(function (entry) {
      return [
        '<div class="ai-calendar-item">',
        '  <div>',
        '    <strong>' + escapeAiHtml(entry.title) + '</strong>',
        '    <span>' + escapeAiHtml(entry.date) + ' • ' + escapeAiHtml(entry.category) + '</span>',
        '  </div>',
        '  <p>' + escapeAiHtml(entry.details) + '</p>',
        '</div>',
      ].join('');
    }).join('') + '</div>',
  ].join('');

  setAiSlotHtml('calendarAiOut', html);
  storeAiExport('calendarAiOut', 'Academic Calendar AI', html, 'Date,Title,Category,Details\n' + results.map(function (entry) {
    return '"' + entry.date + '","' + entry.title.replace(/"/g, '""') + '","' + entry.category + '","' + entry.details.replace(/"/g, '""') + '"';
  }).join('\n'));
  if (persist !== false) {
    saveAiReport('calendar', 'Academic Calendar AI', answer, query || 'Calendar browse', results);
  }
}

function renderAiReports() {
  var root = document.getElementById('aiReportMount');
  if (!root) return;

  var reports = loadAiReports();
  var query = aiNormalizeText(aiStudioState.reportQuery);
  var filter = aiStudioState.reportFilter;

  var filtered = reports.filter(function (report) {
    var matchesFilter = filter === 'all' || report.kind === filter || report.role === filter;
    var haystack = aiNormalizeText(report.title + ' ' + report.summary + ' ' + report.detail + ' ' + report.role);
    var matchesQuery = !query || haystack.indexOf(query) !== -1;
    return matchesFilter && matchesQuery;
  });

  var pages = Math.max(1, Math.ceil(filtered.length / aiStudioState.pageSize));
  if (aiStudioState.reportPage > pages) aiStudioState.reportPage = pages;
  var start = (aiStudioState.reportPage - 1) * aiStudioState.pageSize;
  var pageItems = filtered.slice(start, start + aiStudioState.pageSize);

  root.innerHTML = [
    '<div class="ai-report-toolbar">',
    '  <input id="reportSearchInput" class="ai-search" placeholder="Search saved reports" value="' + escapeAiHtml(aiStudioState.reportQuery) + '"/>',
    '  <select id="reportFilterSelect" class="ai-select">',
    '    <option value="all">All reports</option>',
    '    <option value="student">Student</option>',
    '    <option value="faculty">Faculty</option>',
    '    <option value="admin">Admin</option>',
    '    <option value="calendar">Calendar</option>',
    '  </select>',
    '  <div class="ai-report-actions">',
    '    <button class="btn-sm btn-outline" type="button" onclick="exportAllAiReportsCsv()">Export CSV</button>',
    '  </div>',
    '</div>',
    '<div class="ai-report-list">' + (pageItems.length ? pageItems.map(function (report) {
      return [
        '<div class="ai-report-item">',
        '  <div class="ai-report-head">',
        '    <div>',
        '      <strong>' + escapeAiHtml(report.title) + '</strong>',
        '      <span>' + escapeAiHtml(report.role) + ' • ' + escapeAiHtml(new Date(report.createdAt).toLocaleString()) + '</span>',
        '    </div>',
        '    <span class="badge b-blue">' + escapeAiHtml(report.kind) + '</span>',
        '  </div>',
        '  <p>' + escapeAiHtml(report.summary) + '</p>',
        '  <small>' + escapeAiHtml(report.detail || '') + '</small>',
        '</div>',
      ].join('');
    }).join('') : '<div class="ai-empty">No reports found.</div>') + '</div>',
    '<div class="ai-pagination">',
    '  <button class="btn-sm btn-outline" type="button" ' + (aiStudioState.reportPage <= 1 ? 'disabled' : '') + ' onclick="setAiReportPage(' + (aiStudioState.reportPage - 1) + ')">Previous</button>',
    '  <span>Page ' + aiStudioState.reportPage + ' of ' + pages + '</span>',
    '  <button class="btn-sm btn-outline" type="button" ' + (aiStudioState.reportPage >= pages ? 'disabled' : '') + ' onclick="setAiReportPage(' + (aiStudioState.reportPage + 1) + ')">Next</button>',
    '</div>',
  ].join('');

  var filterEl = document.getElementById('reportFilterSelect');
  if (filterEl) filterEl.value = aiStudioState.reportFilter;

  var searchEl = document.getElementById('reportSearchInput');
  if (searchEl) {
    searchEl.oninput = function () {
      aiStudioState.reportQuery = this.value;
      aiStudioState.reportPage = 1;
      renderAiReports();
    };
  }

  if (filterEl) {
    filterEl.onchange = function () {
      aiStudioState.reportFilter = this.value;
      aiStudioState.reportPage = 1;
      renderAiReports();
    };
  }
}

function setAiReportPage(page) {
  aiStudioState.reportPage = Math.max(1, page);
  renderAiReports();
}

function exportAllAiReportsCsv() {
  var reports = loadAiReports();
  if (!reports.length) {
    toast('No saved reports to export', 'amber');
    return;
  }
  var csv = ['Title,Kind,Role,Summary,Detail,Created At'].concat(reports.map(function (report) {
    return '"' + report.title.replace(/"/g, '""') + '","' + report.kind + '","' + report.role + '","' + report.summary.replace(/"/g, '""') + '","' + String(report.detail || '').replace(/"/g, '""') + '","' + report.createdAt + '"';
  })).join('\n');
  downloadAiText('unierp_ai_reports.csv', csv, 'text/csv;charset=utf-8');
}

function setAiTheme(theme) {
  aiStudioState.theme = theme === 'dark' ? 'dark' : 'light';
  saveAiPreferences();
  applyAiTheme();
}

function applyAiTheme() {
  document.body.classList.toggle('ai-dark', aiStudioState.theme === 'dark');
}

function buildLocalAiReply(text) {
  var query = aiNormalizeText(text);
  var role = currentUser.role;

  if (query.indexOf('next holiday') !== -1 || query.indexOf('holiday') !== -1 || query.indexOf('semester exams') !== -1 || query.indexOf('internal exam') !== -1) {
    return buildCalendarAnswer(text);
  }

  if (query.indexOf('attendance') !== -1 || query.indexOf('miss') !== -1 || query.indexOf('skip') !== -1) {
    var attendance = DB.attendance[currentUser.id] || {};
    var summary = typeof buildAttendanceSummary === 'function' ? buildAttendanceSummary(attendance) : { overallPct: 0, weakest: null };
    if (summary.weakest) {
      return 'Your overall attendance is ' + summary.overallPct + '%. The weakest subject is ' + summary.weakest.subject + ' at ' + summary.weakest.pct + '%.';
    }
    return 'I could not find attendance data for your account.';
  }

  if (query.indexOf('risk') !== -1 && role === 'admin') {
    return 'Open Student Risk Detection to review the highest-risk students and their intervention plans.';
  }

  if (query.indexOf('question paper') !== -1 && role === 'faculty') {
    return 'Use the Question Paper Generator card to create Section A, B, and C questions with Bloom tags.';
  }

  if (query.indexOf('cgpa') !== -1 || query.indexOf('sgpa') !== -1) {
    return 'The CGPA predictor converts your current SGPA, completed credits, and remaining credits into expected, best-case, and worst-case projections.';
  }

  return 'I can help with attendance, CGPA planning, study schedules, question papers, class risk, resource usage, feedback sentiment, and calendar questions. Try a specific request and I will route it to the right AI tool.';
}

async function sendAiChatMessage() {
  var input = document.getElementById('aiChatInput');
  if (!input || aiStudioState.loadingChat) return;
  var text = input.value.trim();
  if (!text) return;

  var log = document.getElementById('aiChatLog');
  if (!log) return;

  appendAiChatMessage('user', text);
  input.value = '';
  aiStudioState.loadingChat = true;
  setAiChatStatus('Thinking...');
  appendAiTyping();

  var history = loadAiChatHistory();
  history.push({ role: 'user', content: text });

  try {
    var reply = await callAiGateway(history);
    removeAiTyping();
    appendAiChatMessage('assistant', reply);
    history.push({ role: 'assistant', content: reply });
    saveAiChatHistory(history);
    setAiChatStatus('Ready');
  } catch (err) {
    removeAiTyping();
    appendAiChatMessage('assistant', 'Nemotron is unavailable right now: ' + err.message + '.');
    history.push({ role: 'assistant', content: 'Nemotron is unavailable right now: ' + err.message + '.' });
    saveAiChatHistory(history);
    setAiChatStatus('Provider unavailable');
  } finally {
    aiStudioState.loadingChat = false;
  }
}

function setAiChatStatus(text) {
  var el = document.getElementById('aiChatStatus');
  if (el) el.textContent = text;
}

function appendAiTyping() {
  var log = document.getElementById('aiChatLog');
  if (!log || document.getElementById('aiTyping')) return;
  var item = document.createElement('div');
  item.className = 'ai-chat-msg assistant';
  item.id = 'aiTyping';
  item.innerHTML = '<div class="ai-chat-bubble"><span class="ai-dots"><i></i><i></i><i></i></span></div>';
  log.appendChild(item);
  log.scrollTop = log.scrollHeight;
}

function removeAiTyping() {
  var typing = document.getElementById('aiTyping');
  if (typing) typing.remove();
}

function appendAiChatMessage(role, content) {
  var log = document.getElementById('aiChatLog');
  if (!log) return;
  var item = document.createElement('div');
  item.className = 'ai-chat-msg ' + role;
  var bubble = document.createElement('div');
  bubble.className = 'ai-chat-bubble';
  bubble.innerHTML = escapeAiHtml(content).replace(/\n/g, '<br>');
  item.innerHTML = '<div class="ai-chat-avatar">' + (role === 'user' ? currentUser.name.charAt(0).toUpperCase() : 'AI') + '</div>';
  item.appendChild(bubble);
  log.appendChild(item);
  log.scrollTop = log.scrollHeight;
}

async function callAiGateway(messages) {
  var payload = {
    model: document.getElementById('aiModelSelect') ? document.getElementById('aiModelSelect').value : '',
    messages: messages,
  };

  var response = await fetch('/api/ai/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error('AI gateway returned ' + response.status);
  }

  var data = await response.json();
  if (data && data.reply) return data.reply;
  if (data && data.output) return data.output;
  return '';
}

function clearAiChat() {
  saveAiChatHistory([]);
  renderAiChat();
  setAiChatStatus('Ready');
}

function renderAiChat() {
  var log = document.getElementById('aiChatLog');
  if (!log) return;
  var history = loadAiChatHistory();
  if (!history.length) {
    log.innerHTML = '';
    appendAiChatMessage('assistant', 'Hi ' + currentUser.name.split(' ')[0] + '. Ask me about attendance, CGPA, question papers, student risk, calendar events, or resource utilization.');
    return;
  }
  log.innerHTML = '';
  history.forEach(function (message) {
    appendAiChatMessage(message.role === 'assistant' ? 'assistant' : 'user', message.content);
  });
}

function renderAiHubHeader() {
  var role = currentUser.role;
  var attendance = DB.attendance[currentUser.id] || {};
  var attendanceSummary = typeof buildAttendanceSummary === 'function' ? buildAttendanceSummary(attendance) : { overallPct: 0 };
  var marks = DB.marks[currentUser.id] || {};
  var average = aiRound(aiAverage(Object.keys(marks).map(function (subject) {
    return normalizeSubjectMarks(marks[subject]);
  })));
  var reports = loadAiReports();

  return [
    '<div class="card ai-hero">',
    '  <div class="ai-hero-copy">',
    '    <span class="ai-badge">Enterprise AI Studio</span>',
    '    <h3>' + aiGetRoleLabel(role) + ' workspace for analytics, planning, and assistant workflows</h3>',
    '    <p>Use one shared AI service layer for performance tracking, question generation, risk detection, calendar RAG, and conversational assistance.</p>',
    '  </div>',
    '  <div class="ai-hero-side">',
    '    <div class="ai-hero-stat"><strong>' + attendanceSummary.overallPct + '%</strong><span>Attendance</span></div>',
    '    <div class="ai-hero-stat"><strong>' + average + '%</strong><span>Marks</span></div>',
    '    <div class="ai-hero-stat"><strong>' + reports.length + '</strong><span>Saved reports</span></div>',
    '  </div>',
    '</div>',
  ].join('');
}

function buildAiToolbar() {
  return [
    '<div class="card ai-toolbar">',
    '  <div class="ai-toolbar-left">',
    '    <div class="fg ai-inline-field">',
      '      <label>Global search</label>',
      '      <input id="aiGlobalSearch" placeholder="Search reports, cards, or calendar questions"/>',
    '    </div>',
    '    <div class="fg ai-inline-field">',
    '      <label>Nemotron model</label>',
    '      <input id="aiModelSelect" value="nvidia/llama-3.1-nemotron-nano-8b-v1"/>',
    '    </div>',
  '  </div>',
    '  <div class="ai-toolbar-right">',
    '    <span class="badge b-blue">Nemotron only</span>',
    '    <button class="btn-sm btn-outline" type="button" onclick="setAiTheme(aiStudioState.theme === \'dark\' ? \'light\' : \'dark\')">Dark mode</button>',
    '    <button class="btn-sm btn-outline" type="button" onclick="exportAllAiReportsCsv()">Export reports</button>',
    '  </div>',
    '</div>',
  ].join('');
}

function renderStudentAiSection() {
  var data = getStudentPerformanceData(currentUser);
  var attendance = DB.attendance[currentUser.id] || {};
  var summary = typeof buildAttendanceSummary === 'function' ? buildAttendanceSummary(attendance) : { overallPct: 0, weakest: null };
  var report = [
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>AI Performance Tracker</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="renderStudentPerformanceOutput()">Analyze</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'studentPerformanceOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'studentPerformanceOut\')">Excel</button></div></div>',
    '  <div class="card-body"><div id="studentPerformanceOut">' + renderMetricStrip([
      { label: 'Overall score', value: data.averageScore + '%', note: 'Current estimate' },
      { label: 'Weakest subject', value: data.weakest ? data.weakest.subject : 'N/A', note: summary.weakest ? summary.weakest.subject + ' attendance: ' + summary.weakest.pct + '%' : 'No attendance data' },
      { label: 'Confidence', value: data.confidence, note: 'Marks and attendance combined' },
    ]) + '</div></div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Attendance Predictor</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="renderAttendancePredictorOutput()">Predict</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'attendancePredictorOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'attendancePredictorOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-form-grid">',
    '      <div class="fg"><label>Total classes</label><input id="ai_att_total" type="number" value="30"/></div>',
    '      <div class="fg"><label>Classes attended</label><input id="ai_att_present" type="number" value="' + (summary.overallTotal ? aiRound(summary.overallTotal * (summary.overallPct / 100)) : 0) + '"/></div>',
    '      <div class="fg"><label>Remaining classes</label><input id="ai_att_remaining" type="number" value="10"/></div>',
    '    </div>',
    '    <div id="attendancePredictorOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Assignment Assistant</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="renderAssignmentAssistantOutput()">Summarize</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'assignmentAssistantOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'assignmentAssistantOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-upload-zone"><input id="assignmentFiles" type="file" multiple onchange="captureAiFiles(\'assignmentUploads\', this)"/><div>Drop or choose PDF, DOCX, TXT, CSV files</div></div>',
    '    <div id="assignmentUploads" class="ai-file-list"></div>',
    '    <div class="fg" style="margin-top:14px;"><label>Prompt hints</label><textarea id="assignmentAssistantPrompt" placeholder="Explain hard concepts, create flashcards, and generate MCQs."></textarea></div>',
    '    <div id="assignmentAssistantOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>AI Study Planner</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="generateStudyPlan()">Generate</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'studyPlannerOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'studyPlannerOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-form-grid">',
    '      <div class="fg"><label>Exam date</label><input id="studyExamDate" type="date"/></div>',
    '      <div class="fg"><label>Study hours / day</label><input id="studyHours" type="number" value="2" min="1" max="12"/></div>',
    '      <div class="fg"><label>Days to plan</label><input id="studyDays" type="number" value="7" min="3" max="30"/></div>',
    '      <div class="fg"><label>Weak subjects</label><input id="studyWeakSubjects" value="' + escapeAiHtml((data.weakest ? data.weakest.subject : '') + (data.weakest ? ', ' : '') + data.weakestTopics.join(', ')) + '"/></div>',
    '    </div>',
    '    <div class="fg" style="margin-top:12px;"><label>Timetable / constraints</label><textarea id="studyTimetable" placeholder="Paste class timings, breaks, and hostel or commute constraints."></textarea></div>',
    '    <div id="studyPlannerOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>CGPA Predictor</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="predictCgpa()">Predict</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'cgpaPredictorOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'cgpaPredictorOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-form-grid">',
    '      <div class="fg"><label>Current SGPA</label><input id="cgpaCurrentSgpa" type="number" step="0.1" value="8.0"/></div>',
    '      <div class="fg"><label>Previous CGPA</label><input id="cgpaPreviousCgpa" type="number" step="0.1" value="7.8"/></div>',
    '      <div class="fg"><label>Completed credits</label><input id="cgpaCompletedCredits" type="number" value="80"/></div>',
    '      <div class="fg"><label>Remaining credits</label><input id="cgpaRemainingCredits" type="number" value="20"/></div>',
    '      <div class="fg"><label>Target CGPA</label><input id="cgpaTarget" type="number" step="0.1" value="8.5"/></div>',
    '    </div>',
    '    <div id="cgpaPredictorOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
  ].join('');

  return report;
}

function renderFacultyAiSection() {
  var subjectOptions = (currentUser.subjects || []).map(function (subject) {
    return '<option value="' + escapeAiHtml(subject) + '">' + escapeAiHtml(subject) + '</option>';
  }).join('');
  return [
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Class Performance Analysis</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="analyzeFacultyClass()">Analyze</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'facultyAnalysisOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'facultyAnalysisOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-form-grid">',
    '      <div class="fg"><label>Subject</label><select id="facultySubjectSelect">' + subjectOptions + '</select></div>',
    '    </div>',
    '    <div id="facultyAnalysisOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Automatic Question Paper Generator</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="generateQuestionPaper()">Generate</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'questionPaperOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'questionPaperOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-form-grid">',
    '      <div class="fg"><label>Subject</label><input id="qpSubject" value="' + escapeAiHtml((currentUser.subjects || [])[0] || '') + '"/></div>',
    '      <div class="fg"><label>Unit</label><input id="qpUnit" value="1"/></div>',
    '      <div class="fg"><label>Topics</label><input id="qpTopics" value="Concepts, Applications, Practice"/></div>',
    '      <div class="fg"><label>Difficulty</label><select id="qpDifficulty"><option>Easy</option><option selected>Medium</option><option>Hard</option></select></div>',
    '      <div class="fg"><label>Total marks</label><input id="qpMarks" type="number" value="50" min="20" max="100"/></div>',
    '    </div>',
    '    <div id="questionPaperOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Assignment Evaluation Assistant</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="evaluateAssignments()">Evaluate</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'assignmentEvaluationOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'assignmentEvaluationOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-upload-zone"><input id="evaluationFiles" type="file" multiple onchange="captureAiFiles(\'evaluationUploads\', this)"/><div>Upload student submissions for feedback and similarity checks</div></div>',
    '    <div id="evaluationUploads" class="ai-file-list"></div>',
    '    <div id="assignmentEvaluationOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
  ].join('');
}

function renderAdminAiSection() {
  return [
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Student Risk Detection</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="analyzeStudentRisk()">Analyze</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'adminRiskOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'adminRiskOut\')">Excel</button></div></div>',
    '  <div class="card-body"><div id="adminRiskOut"></div></div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Resource Utilization Analytics</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="analyzeResources()">Analyze</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'adminResourcesOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'adminResourcesOut\')">Excel</button></div></div>',
    '  <div class="card-body"><div id="adminResourcesOut"></div></div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Feedback Sentiment Analysis</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="analyzeFeedback()">Analyze</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'adminFeedbackOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'adminFeedbackOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="ai-summary-box"><strong>Upload support</strong><p>CSV and text-based files can be analyzed in the browser. Excel uploads can be forwarded to the backend parser when connected.</p></div>',
    '    <div id="adminFeedbackOut"></div>',
    '  </div>',
    '</div>',
  ].join('');
}

function renderSharedAiSection() {
  return [
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>Academic Calendar AI</h3><div class="btn-row"><button class="btn-sm btn-primary" onclick="renderCalendarSection()">Search</button><button class="btn-sm btn-outline" onclick="exportAiSlotPdf(\'calendarAiOut\')">PDF</button><button class="btn-sm btn-outline" onclick="exportAiSlotExcel(\'calendarAiOut\')">Excel</button></div></div>',
    '  <div class="card-body">',
    '    <div class="fg"><label>Ask a question</label><input id="calendarSearch" placeholder="When is the next holiday? When do semester exams start?"/></div>',
    '    <div id="calendarAiOut" style="margin-top:16px;"></div>',
    '  </div>',
    '</div>',
    '<div class="card ai-panel">',
    '  <div class="card-header"><h3>AI Concierge</h3><div class="btn-row"><span class="badge b-gray" id="aiChatStatus">Ready</span><button class="btn-sm btn-outline" onclick="clearAiChat()">Clear</button></div></div>',
    '  <div class="card-body ai-chat-body">',
    '    <div class="ai-chat-log" id="aiChatLog"></div>',
    '    <div class="ai-chat-compose">',
    '      <textarea id="aiChatInput" placeholder="Ask an AI question and hit Enter"></textarea>',
    '      <button class="btn-sm btn-primary" type="button" onclick="sendAiChatMessage()">Send</button>',
    '    </div>',
    '  </div>',
    '</div>',
  ].join('');
}

function renderAiHub(container) {
  loadAiPreferences();
  applyAiTheme();

  var root = document.getElementById('content') ? container : null;
  if (!root) return;

  var html = [
    '<div class="ai-shell">',
    renderAiHubHeader(),
    buildAiToolbar(),
    '<div class="ai-layout">',
    '  <div class="ai-main">',
    '    ' + (currentUser.role === 'student' ? renderStudentAiSection() : currentUser.role === 'faculty' ? renderFacultyAiSection() : renderAdminAiSection()),
    '    ' + renderSharedAiSection(),
    '  </div>',
    '  <aside class="ai-side">',
    '    <div class="card ai-panel">',
    '      <div class="card-header"><h3>Saved AI Reports</h3><span class="badge b-gray">Search + pagination</span></div>',
    '      <div class="card-body" id="aiReportMount"></div>',
    '    </div>',
    '  </aside>',
    '</div>',
    '</div>',
  ].join('');

  container.innerHTML = html;

  var search = document.getElementById('aiGlobalSearch');
  if (search) {
    search.oninput = function () {
      aiStudioState.reportQuery = this.value;
      aiStudioState.reportPage = 1;
      renderAiReports();
      filterAiCards(this.value);
    };
  }

  var calendarSearch = document.getElementById('calendarSearch');
  if (calendarSearch) {
    calendarSearch.oninput = function () {
      renderCalendarSection(false);
    };
  }

  aiStudioState.skipSave = true;
  try {
    renderAiReports();
    renderCalendarSection();
    renderAiChat();

    if (currentUser.role === 'student') {
      renderStudentPerformanceOutput();
      renderAttendancePredictorOutput();
      renderFilePreview('assignmentUploads');
      generateStudyPlan();
      predictCgpa();
    } else if (currentUser.role === 'faculty') {
      analyzeFacultyClass();
      generateQuestionPaper();
    } else {
      analyzeStudentRisk();
      analyzeResources();
      analyzeFeedback();
    }
  } finally {
    aiStudioState.skipSave = false;
  }

  setTimeout(function () {
    filterAiCards(document.getElementById('aiGlobalSearch') ? document.getElementById('aiGlobalSearch').value : '');
  }, 0);
}

function filterAiCards(query) {
  var text = aiNormalizeText(query);
  document.querySelectorAll('.ai-panel').forEach(function (panel) {
    var haystack = aiNormalizeText(panel.textContent || '');
    panel.style.display = !text || haystack.indexOf(text) !== -1 ? '' : 'none';
  });
}

function handleAiHubKeydown(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendAiChatMessage();
  }
}

document.addEventListener('DOMContentLoaded', function () {
  var chatInput = document.getElementById('aiChatInput');
  if (chatInput) {
    chatInput.addEventListener('keydown', handleAiHubKeydown);
  }
});

function aiHub(container) {
  return renderAiHub(container);
}

window.aiHub = aiHub;
window.renderStudentPerformanceOutput = renderStudentPerformanceOutput;
window.renderAttendancePredictorOutput = renderAttendancePredictorOutput;
window.renderAssignmentAssistantOutput = renderAssignmentAssistantOutput;
window.generateStudyPlan = generateStudyPlan;
window.predictCgpa = predictCgpa;
window.analyzeFacultyClass = analyzeFacultyClass;
window.generateQuestionPaper = generateQuestionPaper;
window.evaluateAssignments = evaluateAssignments;
window.analyzeStudentRisk = analyzeStudentRisk;
window.analyzeResources = analyzeResources;
window.analyzeFeedback = analyzeFeedback;
window.renderCalendarSection = renderCalendarSection;
window.sendAiChatMessage = sendAiChatMessage;
window.clearAiChat = clearAiChat;
window.setAiReportPage = setAiReportPage;
window.exportAllAiReportsCsv = exportAllAiReportsCsv;
window.setAiTheme = setAiTheme;
window.exportAiSlotPdf = exportAiSlotPdf;
window.exportAiSlotExcel = exportAiSlotExcel;
window.captureAiFiles = captureAiFiles;
