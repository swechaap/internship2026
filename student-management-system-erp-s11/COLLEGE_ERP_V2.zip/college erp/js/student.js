var ATTENDANCE_BOT_CONFIG = {
  appTitle: 'UniERP Attendance Bot',
};

var attendanceBotState = {
  userId: null,
  history: [],
  loading: false,
  typing: false,
};

function buildAttendanceSummary(attendance) {
  var subjects = Object.keys(attendance || {}).map(function (subject) {
    var days = attendance[subject] || [];
    var present = days.filter(function (day) {
      return day === 1;
    }).length;
    var total = days.length;
    var pct = total ? Math.round((present / total) * 100) : 0;
    var canSkip = pct >= 75 ? Math.max(0, Math.floor((present - 0.75 * total) / 0.25)) : 0;
    var needToReach75 = pct >= 75 ? 0 : Math.max(0, Math.ceil(0.75 * total - present));

    return {
      subject: subject,
      present: present,
      absent: total - present,
      total: total,
      pct: pct,
      canSkip: canSkip,
      needToReach75: needToReach75,
      status: pct >= 75 ? 'safe' : 'risk',
    };
  });

  var overallPresent = subjects.reduce(function (sum, item) {
    return sum + item.present;
  }, 0);
  var overallTotal = subjects.reduce(function (sum, item) {
    return sum + item.total;
  }, 0);
  var overallPct = overallTotal ? Math.round((overallPresent / overallTotal) * 100) : 0;
  var weakest = subjects.slice().sort(function (a, b) {
    return a.pct - b.pct;
  })[0] || null;

  return {
    subjects: subjects,
    overallPresent: overallPresent,
    overallTotal: overallTotal,
    overallPct: overallPct,
    weakest: weakest,
  };
}

function buildAttendanceSystemPrompt(student, summary) {
  var subjectLines = summary.subjects.map(function (item) {
    return [
      '- ' + item.subject + ':',
      'present ' + item.present + '/' + item.total,
      'attendance ' + item.pct + '%',
      item.status === 'safe' ? 'safe' : 'below 75%',
      'can skip ' + item.canSkip + ' more class' + (item.canSkip === 1 ? '' : 'es') + ' safely',
      'needs ' + item.needToReach75 + ' more class' + (item.needToReach75 === 1 ? '' : 'es') + ' to reach 75%',
    ].join(', ');
  }).join('\n');

  return [
    'You are a friendly attendance assistant inside UniERP.',
    'Only answer about attendance, safe-to-skip calculations, recovery plans, and subject-wise risk.',
    'If the user asks about anything unrelated, politely redirect back to attendance help.',
    'Use the exact numbers below and do not invent attendance data.',
    'Minimum required attendance is 75% per subject.',
    '',
    'Student details:',
    '- Name: ' + student.name,
    '- ID: ' + student.id,
    '- Department: ' + student.dept,
    '- Year: ' + student.year,
    '- Section: ' + student.section,
    '- Overall attendance: ' + summary.overallPct + '%',
    '',
    'Subject attendance:',
    subjectLines || '- No attendance records found.',
    '',
    'Helpful rules:',
    '- Be conversational, warm, and concise.',
    '- Always include exact class counts when the student asks what to do next.',
    '- If a subject is below 75%, explain how many classes are needed to recover.',
    '- If a subject is safe, say how many more classes can be missed safely.',
    '- If asked which subject is weakest, answer with the lowest percentage subject.',
  ].join('\n');
}

function normalizeAttendanceText(text) {
  return String(text || '').toLowerCase().replace(/[^a-z0-9% ]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function findAttendanceSubject(text, subjects) {
  var lower = normalizeAttendanceText(text);
  var match = null;
  (subjects || []).forEach(function (subject) {
    var subjectLower = normalizeAttendanceText(subject);
    if (!subjectLower) return;
    if (lower.indexOf(subjectLower) !== -1) {
      match = subject;
    }
  });
  return match;
}

function formatAttendanceSubjectLine(item) {
  if (item.status === 'safe') {
    return item.subject + ': ' + item.pct + '%, safe to miss ' + item.canSkip + ' more class' + (item.canSkip === 1 ? '' : 'es') + '.';
  }
  return item.subject + ': ' + item.pct + '%, needs ' + item.needToReach75 + ' more class' + (item.needToReach75 === 1 ? '' : 'es') + ' to reach 75%.';
}

function generateAttendanceBotReply(userText, student, summary) {
  var query = normalizeAttendanceText(userText);
  var subjects = summary.subjects || [];
  var subjectName = findAttendanceSubject(userText, subjects.map(function (item) { return item.subject; }));
  var subjectItem = subjectName ? subjects.find(function (item) { return item.subject === subjectName; }) : null;

  if (!subjects.length) {
    return 'I could not find any attendance records for you.';
  }

  if (query.indexOf('overall') !== -1 || query.indexOf('total attendance') !== -1 || query.indexOf('all subjects') !== -1) {
    var weakestLine = summary.weakest ? summary.weakest.subject + ' at ' + summary.weakest.pct + '%' : 'no weak subject';
    return 'Your overall attendance is ' + summary.overallPct + '%. The weakest subject is ' + weakestLine + '.';
  }

  if (query.indexOf('lowest') !== -1 || query.indexOf('most at risk') !== -1 || query.indexOf('at risk') !== -1 || query.indexOf('weakest') !== -1) {
    if (!summary.weakest) return 'I could not identify a weakest subject right now.';
    return summary.weakest.subject + ' is your weakest subject at ' + summary.weakest.pct + '%. You need ' + summary.weakest.needToReach75 + ' more class' + (summary.weakest.needToReach75 === 1 ? '' : 'es') + ' to reach 75%.';
  }

  if (query.indexOf('full') !== -1 || query.indexOf('detailed') !== -1 || query.indexOf('breakdown') !== -1 || query.indexOf('subject wise') !== -1) {
    return 'Here is your subject-wise attendance:\n' + subjects.map(function (item) {
      return '- ' + formatAttendanceSubjectLine(item);
    }).join('\n');
  }

  if (query.indexOf('how many') !== -1 && (query.indexOf('miss') !== -1 || query.indexOf('skip') !== -1 || query.indexOf('can i') !== -1 || query.indexOf('can i miss') !== -1)) {
    if (subjectItem) {
      return subjectItem.subject + ': you can miss ' + subjectItem.canSkip + ' more class' + (subjectItem.canSkip === 1 ? '' : 'es') + ' safely. ';
    }
    return 'Safe-to-skip by subject:\n' + subjects.map(function (item) {
      return '- ' + item.subject + ': ' + item.canSkip + ' more class' + (item.canSkip === 1 ? '' : 'es') + ' safely.';
    }).join('\n');
  }

  if (query.indexOf('reach 75') !== -1 || query.indexOf('back to 75') !== -1 || query.indexOf('recover') !== -1 || query.indexOf('need to attend') !== -1) {
    if (subjectItem) {
      return subjectItem.subject + ': attend ' + subjectItem.needToReach75 + ' more class' + (subjectItem.needToReach75 === 1 ? '' : 'es') + ' to reach 75%.';
    }
    var below = subjects.filter(function (item) { return item.status !== 'safe'; });
    if (!below.length) return 'You are already at or above 75% in every subject.';
    return 'Subjects below 75%:\n' + below.map(function (item) {
      return '- ' + item.subject + ': attend ' + item.needToReach75 + ' more class' + (item.needToReach75 === 1 ? '' : 'es') + ' to reach 75%.';
    }).join('\n');
  }

  if (query.indexOf('safe') !== -1 || query.indexOf('skip one more') !== -1 || query.indexOf('am i safe') !== -1) {
    if (subjectItem) {
      if (subjectItem.canSkip > 0) {
        return 'Yes, for ' + subjectItem.subject + ' you can safely miss 1 more class. You still have room for ' + subjectItem.canSkip + ' classes total.';
      }
      return 'No, for ' + subjectItem.subject + ' you are not safe to skip another class. You need to attend ' + subjectItem.needToReach75 + ' more class' + (subjectItem.needToReach75 === 1 ? '' : 'es') + ' to reach 75%.';
    }
    if (summary.weakest && summary.weakest.status !== 'safe') {
      return 'You should avoid skipping right now. Your weakest subject is ' + summary.weakest.subject + ' at ' + summary.weakest.pct + '%.';
    }
  }

  if (query.indexOf('hello') !== -1 || query.indexOf('hi') !== -1) {
    return 'Hi ' + student.name.split(' ')[0] + '! Ask me about your attendance, safe-to-skip limit, or which subject is at risk.';
  }

  return 'I can help with attendance questions like overall attendance, weakest subject, safe-to-skip limits, and how to recover to 75%. Try asking: "How many more classes can I miss in DBMS?"';
}

function attendanceBotStorageKey(studentId) {
  return 'unierp_attendance_bot_' + studentId;
}

function loadAttendanceBotHistory(studentId) {
  try {
    var raw = window.localStorage.getItem(attendanceBotStorageKey(studentId));
    var parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed)
      ? parsed.filter(function (item) {
        return item && (item.role === 'user' || item.role === 'assistant') && typeof item.content === 'string';
      })
      : [];
  } catch (err) {
    return [];
  }
}

function saveAttendanceBotHistory(studentId) {
  try {
    window.localStorage.setItem(attendanceBotStorageKey(studentId), JSON.stringify(attendanceBotState.history.slice(-20)));
  } catch (err) {
    // Ignore storage failures in private or restricted browsing contexts.
  }
}

function getAttendanceBotMessageArea() {
  return document.getElementById('attendanceBotMessages');
}

function getAttendanceBotInput() {
  return document.getElementById('attendanceBotInput');
}

function setAttendanceBotStatus(state, label) {
  var el = document.getElementById('attendanceBotStatus');
  if (!el) return;

  if (state === 'ready') {
    el.className = 'badge b-green attendance-bot-status';
  } else if (state === 'loading') {
    el.className = 'badge b-amber attendance-bot-status';
  } else if (state === 'error') {
    el.className = 'badge b-red attendance-bot-status';
  } else {
    el.className = 'badge b-gray attendance-bot-status';
  }

  el.textContent = label;
}

function formatAttendanceBotMessage(text) {
  return String(text || '')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.*?)`/g, '<code>$1</code>')
    .replace(/(\d+)%/g, function (match, value) {
      var num = parseInt(value, 10);
      var cls = num >= 75 ? 'att-hl-green' : num >= 60 ? 'att-hl-amber' : 'att-hl-red';
      return '<span class="att-highlight ' + cls + '">' + value + '%</span>';
    })
    .replace(/\n/g, '<br>');
}

function appendAttendanceBotMessage(role, text) {
  var msgs = getAttendanceBotMessageArea();
  if (!msgs) return;

  var item = document.createElement('div');
  item.className = 'att-msg ' + role;

  var av = document.createElement('div');
  av.className = 'att-msg-av';
  av.textContent = role === 'user' ? currentUser.name.charAt(0).toUpperCase() : 'AI';

  var bubble = document.createElement('div');
  bubble.className = 'att-msg-bubble';
  bubble.innerHTML = formatAttendanceBotMessage(text);

  item.appendChild(av);
  item.appendChild(bubble);
  msgs.appendChild(item);
  msgs.scrollTop = msgs.scrollHeight;
}

function showAttendanceBotTyping() {
  var msgs = getAttendanceBotMessageArea();
  if (!msgs || document.getElementById('attendanceBotTyping')) return;

  var item = document.createElement('div');
  item.className = 'att-msg bot';
  item.id = 'attendanceBotTyping';
  item.innerHTML = '<div class="att-msg-av">AI</div><div class="att-msg-bubble" style="padding:10px 14px;"><div class="att-typing"><span></span><span></span><span></span></div></div>';
  msgs.appendChild(item);
  msgs.scrollTop = msgs.scrollHeight;
}

function removeAttendanceBotTyping() {
  var typing = document.getElementById('attendanceBotTyping');
  if (typing) typing.remove();
}

function resizeAttendanceBotInput(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function clearAttendanceBotChat() {
  attendanceBotState.history = [];
  saveAttendanceBotHistory(attendanceBotState.userId);
  renderAttendanceBotTimeline();
  setAttendanceBotStatus('ready', 'Ready');
}

function renderAttendanceBotTimeline() {
  var msgs = getAttendanceBotMessageArea();
  if (!msgs) return;

  msgs.innerHTML = '';

  if (!attendanceBotState.history.length) {
    appendAttendanceBotMessage('bot', 'Hi ' + currentUser.name.split(' ')[0] + '! I can help you understand your attendance, tell you which subject is at risk, and calculate how many classes you can still miss safely.');
    return;
  }

  attendanceBotState.history.forEach(function (message) {
    appendAttendanceBotMessage(message.role === 'assistant' ? 'bot' : 'user', message.content);
  });
}

function renderAttendanceBot(student, summary) {
  var container = document.getElementById('attendanceBotMount');
  if (!container) return;

  attendanceBotState.userId = student.id;
  attendanceBotState.history = loadAttendanceBotHistory(student.id);

  container.innerHTML = `
    <div class="card attendance-bot-card">
      <div class="card-header">
        <div>
          <h3>Attendance Assistant</h3>
          <div class="attendance-bot-headline">Ask about safe-to-skip limits, recovery plans, and subject-wise risk.</div>
        </div>
        <span class="badge b-gray attendance-bot-status" id="attendanceBotStatus">Ready</span>
      </div>
      <div class="card-body attendance-bot-body">
        <div class="attendance-bot-toolbar">
          <div class="attendance-bot-summary">
            <strong>${summary.overallPct}% overall</strong>
            <span>${summary.weakest ? 'Lowest: ' + summary.weakest.subject + ' (' + summary.weakest.pct + '%)' : 'No attendance records found'}</span>
          </div>
          <button class="btn-sm btn-outline" type="button" id="attendanceBotClearBtn">Clear chat</button>
        </div>
        <div class="attendance-bot-messages" id="attendanceBotMessages"></div>
        <div class="attendance-bot-suggestions">
          <button class="att-chip" type="button" data-att-ask="What is my overall attendance percentage and my lowest subject?">Overall attendance</button>
          <button class="att-chip" type="button" data-att-ask="Which subject am I most at risk in?">Most at risk</button>
          <button class="att-chip" type="button" data-att-ask="How many more classes can I miss in each subject before I fall below 75%?">Safe-to-skip</button>
          <button class="att-chip" type="button" data-att-ask="How many classes do I need to attend to get every subject back to 75%?">Recover to 75%</button>
        </div>
        <div class="attendance-bot-compose">
          <textarea class="attendance-bot-input" id="attendanceBotInput" rows="1" placeholder="Ask something like: Am I safe to skip one more class in DBMS?" onkeydown="handleAttendanceBotKey(event)" oninput="resizeAttendanceBotInput(this)"></textarea>
          <button class="btn-sm btn-primary attendance-bot-send" type="button" id="attendanceBotSendBtn">Send</button>
        </div>
      </div>
    </div>`;

  document.getElementById('attendanceBotSendBtn').onclick = function () {
    sendAttendanceBotMessage();
  };

  document.getElementById('attendanceBotClearBtn').onclick = function () {
    clearAttendanceBotChat();
  };

  document.querySelectorAll('[data-att-ask]').forEach(function (button) {
    button.onclick = function () {
      var input = getAttendanceBotInput();
      if (!input) return;
      input.value = button.getAttribute('data-att-ask');
      resizeAttendanceBotInput(input);
      sendAttendanceBotMessage();
    };
  });

  setAttendanceBotStatus('ready', 'Ready');
  renderAttendanceBotTimeline();
}

function handleAttendanceBotKey(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendAttendanceBotMessage();
  }
}

async function sendAttendanceBotMessage() {
  var input = getAttendanceBotInput();
  var userText = input ? input.value.trim() : '';
  if (!userText || attendanceBotState.loading) return;

  input.value = '';
  resizeAttendanceBotInput(input);
  appendAttendanceBotMessage('user', userText);
  setAttendanceBotStatus('loading', 'Thinking...');
  attendanceBotState.loading = true;
  document.getElementById('attendanceBotSendBtn').disabled = true;
  showAttendanceBotTyping();

  var summary = buildAttendanceSummary(DB.attendance[currentUser.id] || {});

  try {
    var reply = generateAttendanceBotReply(userText, currentUser, summary);
    removeAttendanceBotTyping();
    appendAttendanceBotMessage('bot', reply);
    attendanceBotState.history.push({ role: 'user', content: userText });
    attendanceBotState.history.push({ role: 'assistant', content: reply });
    saveAttendanceBotHistory(attendanceBotState.userId);
    setAttendanceBotStatus('ready', 'Ready');
  } catch (err) {
    removeAttendanceBotTyping();
    setAttendanceBotStatus('error', 'Error');
    appendAttendanceBotMessage('bot', 'I could not generate a reply: ' + err.message + '.');
  } finally {
    attendanceBotState.loading = false;
    document.getElementById('attendanceBotSendBtn').disabled = false;
  }
}

function stuDashboard(container) {
  var student = currentUser;
  var attendance = DB.attendance[student.id] || {};
  var allDays = Object.values(attendance).flat();
  var attendancePct = allDays.length ? Math.round(allDays.reduce(function (a, b) { return a + b; }, 0) / allDays.length * 100) : 0;
  var marks = DB.marks[student.id] || {};
  var finals = Object.values(marks).map(function (mark) { return mark.final || 0; });
  var average = finals.length ? Math.round(finals.reduce(function (a, b) { return a + b; }, 0) / finals.length) : 0;
  var myAssignments = DB.assignments.filter(function (assignment) {
    var faculty = DB.users.find(function (user) {
      return user.id === assignment.faculty;
    });
    return faculty && facultyMatchesStudentDept(faculty, student.dept);
  });
  var pending = myAssignments.filter(function (assignment) {
    return !assignment.submissions.some(function (submission) {
      return submission.sid === student.id;
    });
  }).length;
  container.innerHTML = `
  <div style="background:linear-gradient(135deg,#0f2744,#1a3a5c);border-radius:12px;padding:24px;color:#fff;margin-bottom:20px;display:flex;align-items:center;gap:20px;">
    <div style="width:64px;height:64px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:800;border:3px solid rgba(255,255,255,.3);">${student.name[0]}</div>
    <div><div style="font-size:20px;font-weight:700;">Welcome, ${student.name.split(' ')[0]}!</div>
    <div style="opacity:.7;font-size:13px;margin-top:3px;">${student.dept} · Year ${student.year} · Section ${student.section}</div></div>
  </div>
  <div class="stat-grid">
    <div class="stat-card"><div class="sc-icon">Attendance</div><div class="sc-val" style="color:${attendancePct < 75 ? 'var(--red)' : 'var(--green)'}">${attendancePct}%</div><div class="sc-lbl">Attendance</div><div class="sc-tag ${attendancePct < 75 ? 'tag-red' : 'tag-green'}">${attendancePct < 75 ? 'Low' : 'Good'}</div></div>
    <div class="stat-card"><div class="sc-icon">Marks</div><div class="sc-val">${average}/100</div><div class="sc-lbl">Avg Marks</div><div class="sc-tag ${average >= 60 ? 'tag-green' : 'tag-amber'}">${average >= 60 ? 'Passing' : 'At Risk'}</div></div>
    <div class="stat-card"><div class="sc-icon">Assignments</div><div class="sc-val">${pending}</div><div class="sc-lbl">Pending Assignments</div><div class="sc-tag tag-amber">Due</div></div>
    <div class="stat-card"><div class="sc-icon">Notices</div><div class="sc-val">${DB.notices.length}</div><div class="sc-lbl">New Notices</div><div class="sc-tag tag-blue">Unread</div></div>
  </div>
  <div class="card">
    <div class="card-header"><h3>Quick Links</h3></div>
    <div class="card-body"><div class="btn-row">
      <button class="btn-sm btn-primary" onclick="navigate('stuAttendance')">View Attendance</button>
      <button class="btn-sm btn-teal" onclick="navigate('stuMarks')">My Marks</button>
      <button class="btn-sm btn-outline" onclick="navigate('stuAssignments')">Assignments</button>
      <button class="btn-sm btn-outline" onclick="navigate('stuQuizzes')">Take Quiz</button>
    </div></div>
  </div>`;
}

function stuAttendance(container) {
  var student = currentUser;
  var attendance = DB.attendance[student.id] || {};
  var summary = buildAttendanceSummary(attendance);
  var subjects = Object.keys(attendance);
  var html = `
  <div class="stat-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
    ${subjects.map(function (subject) {
      var days = attendance[subject];
      var pct = days.length ? Math.round(days.reduce(function (a, b) { return a + b; }, 0) / days.length * 100) : 0;
      var present = days.filter(function (day) { return day === 1; }).length;
      return `<div class="stat-card">
        <div style="font-weight:700;font-size:14px;margin-bottom:8px;">${subject}</div>
        <div class="sc-val" style="color:${pct < 75 ? 'var(--red)' : 'var(--green)'}">${pct}%</div>
        <div class="sc-lbl">${present}/${days.length} classes</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:${pct < 75 ? 'var(--red)' : 'var(--green)'}"></div></div>
        <div class="sc-tag ${pct < 75 ? 'tag-red' : 'tag-green'}">${pct < 75 ? 'Below 75%' : 'Good standing'}</div>
      </div>`;
    }).join('')}
  </div>
  ${subjects.map(function (subject) {
    var days = attendance[subject];
    return `<div class="card">
      <div class="card-header"><h3>${subject} - Session-wise Record</h3></div>
      <div class="card-body">
        <div class="att-grid">
          ${days.map(function (day, index) { return `<div class="att-day ${day ? 'att-present' : 'att-absent'}" title="Session ${index + 1}">${index + 1}</div>`; }).join('')}
        </div>
        <div style="display:flex;gap:14px;margin-top:14px;font-size:12px;">
          <span>Present</span><span>Absent</span>
        </div>
      </div>
    </div>`;
  }).join('')}
  <div id="attendanceBotMount" style="margin-top:24px;"></div>`;
  container.innerHTML = html;
  renderAttendanceBot(student, summary);
}

function stuMarks(container) {
  var student = currentUser;
  var marks = DB.marks[student.id] || {};
  var subjects = Object.keys(marks);
  container.innerHTML = `
  ${subjects.map(function (subject) {
    var mark = marks[subject];
    var total = mark.mid1 + mark.mid2 + mark.assign + mark.final;
    var max = 50 + 50 + 20 + 100;
    var pct = Math.round(total / max * 100);
    var grade = mark.final >= 90 ? 'O' : mark.final >= 80 ? 'A+' : mark.final >= 70 ? 'A' : mark.final >= 60 ? 'B+' : mark.final >= 50 ? 'B' : 'F';
    var gradeClass = mark.final >= 60 ? 'b-green' : mark.final >= 50 ? 'b-amber' : 'b-red';
    return `<div class="card">
      <div class="card-header">
        <h3>${subject}</h3>
        <span class="badge ${gradeClass}" style="font-size:16px;padding:4px 14px;">${grade}</span>
      </div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px;">
          <div class="info-item"><div class="ii-lbl">Mid-1</div><div class="ii-val">${mark.mid1}/50</div></div>
          <div class="info-item"><div class="ii-lbl">Mid-2</div><div class="ii-val">${mark.mid2}/50</div></div>
          <div class="info-item"><div class="ii-lbl">Assignment</div><div class="ii-val">${mark.assign}/20</div></div>
          <div class="info-item"><div class="ii-lbl">Final Exam</div><div class="ii-val">${mark.final}/100</div></div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-size:13px;color:var(--muted);">Overall: ${total}/${max}</span>
          <div class="progress-bar" style="flex:1;"><div class="progress-fill" style="width:${pct}%;"></div></div>
          <span style="font-size:13px;font-weight:700;">${pct}%</span>
        </div>
      </div>
    </div>`;
  }).join('')}`;
}

function stuAssignments(container) {
  var student = currentUser;
  var myAssignments = DB.assignments.filter(function (assignment) {
    var faculty = DB.users.find(function (user) {
      return user.id === assignment.faculty;
    });
    return faculty && facultyMatchesStudentDept(faculty, student.dept);
  });
  container.innerHTML = `
  <div class="card">
    <div class="card-header"><h3>My Assignments</h3></div>
    <div class="card-body">
      ${myAssignments.map(function (assignment) {
        var submitted = assignment.submissions.find(function (submission) {
          return submission.sid === student.id;
        });
        return `<div style="border:1px solid var(--border);border-radius:10px;padding:18px;margin-bottom:12px;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <div style="font-weight:700;font-size:15px;">${assignment.title}</div>
              <div style="font-size:12px;color:var(--muted);margin-top:4px;">${assignment.subject} · Due: ${assignment.due} · Max: ${assignment.maxMarks} marks</div>
              ${submitted ? `<div style="margin-top:6px;font-size:12px;color:var(--green);">Submitted: ${submitted.file} ${submitted.marks != null ? '· Marks: ' + submitted.marks : '· Awaiting evaluation'}</div>` : ''}
            </div>
            <span class="badge ${submitted ? 'b-green' : 'b-amber'}">${submitted ? 'Submitted' : 'Pending'}</span>
          </div>
          ${!submitted ? `<div style="margin-top:12px;" id="upzone_${assignment.id}">
            <div class="upload-zone" onclick="triggerUpload('${assignment.id}')" id="uz_${assignment.id}">
              <div class="uz-icon">File</div>
              <div style="font-weight:600;font-size:14px;">Click to upload file</div>
              <div style="font-size:12px;color:var(--muted);margin-top:4px;">PDF, DOC, ZIP accepted</div>
            </div>
            <input type="file" id="file_${assignment.id}" style="display:none" onchange="handleFileSubmit('${assignment.id}',this)"/>
          </div>` : ''}
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

function triggerUpload(id) {
  document.getElementById('file_' + id)?.click();
}

function handleFileSubmit(aid, input) {
  var file = input.files[0];
  if (!file) return;
  var assignment = DB.assignments.find(function (candidate) {
    return candidate.id === aid;
  });
  if (!assignment) return;
  assignment.submissions.push({
    sid: currentUser.id,
    name: currentUser.name,
    file: file.name,
    date: new Date().toLocaleDateString(),
    marks: null,
  });
  toast('"' + file.name + '" submitted successfully');
  navigate('stuAssignments');
}

function stuQuizzes(container) {
  var student = currentUser;
  var myQuizzes = DB.quizzes.filter(function (quiz) {
    var faculty = DB.users.find(function (user) {
      return user.id === quiz.faculty;
    });
    return faculty && facultyMatchesStudentDept(faculty, student.dept);
  });
  container.innerHTML = `
  <div class="card">
    <div class="card-header"><h3>Available Quizzes</h3></div>
    <div class="card-body">
      ${myQuizzes.map(function (quiz) {
        var done = DB.quizResults[quiz.id + '_' + student.id];
        return `<div style="border:1px solid var(--border);border-radius:10px;padding:18px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
          <div>
            <div style="font-weight:700;font-size:15px;">${quiz.title}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px;">${quiz.subject} · ${quiz.questions.length} questions · ${quiz.timeLimit} mins</div>
            ${done ? `<div style="font-size:12px;color:var(--green);margin-top:4px;">Score: ${done.score}/${quiz.questions.length}</div>` : ''}
          </div>
          <button class="btn-sm ${done ? 'btn-outline' : 'btn-primary'}" onclick="startQuiz('${quiz.id}')">${done ? 'Retake' : 'Start Quiz'}</button>
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

function startQuiz(qid) {
  var quiz = DB.quizzes.find(function (candidate) {
    return candidate.id === qid;
  });
  if (!quiz) return;
  quizState = { qid: qid, current: 0, answers: [], started: Date.now() };
  renderQuizQuestion();
}

function renderQuizQuestion() {
  var quiz = DB.quizzes.find(function (candidate) {
    return candidate.id === quizState.qid;
  });
  var index = quizState.current;
  var question = quiz.questions[index];
  var total = quiz.questions.length;
  var progress = Math.round(index / total * 100);
  openModal(quiz.title + ' - Q' + (index + 1) + '/' + total, `
    <div class="progress-bar"><div class="progress-fill" style="width:${progress}%"></div></div>
    <div style="font-size:15px;font-weight:600;margin:16px 0 12px;">${question.q}</div>
    <div id="quizOpts">
      ${question.opts.map(function (option, optionIndex) {
        return `<div class="quiz-option ${quizState.answers[index] === optionIndex ? 'selected' : ''}" onclick="selectOpt(${optionIndex})" id="qopt_${optionIndex}">${option}</div>`;
      }).join('')}
    </div>
  `, [
    { label: index === 0 ? 'Cancel' : 'Previous', cls: 'btn-sm btn-outline', action: index === 0 ? closeModal : prevQuestion },
    { label: index === total - 1 ? 'Submit Quiz' : 'Next', cls: 'btn-sm btn-primary', action: index === total - 1 ? submitQuiz : nextQuestion },
  ]);
}

function selectOpt(i) {
  quizState.answers[quizState.current] = i;
  document.querySelectorAll('.quiz-option').forEach(function (element, index) {
    element.classList.toggle('selected', index === i);
  });
}

function nextQuestion() {
  if (quizState.answers[quizState.current] === undefined) {
    toast('Please select an answer', 'amber');
    return;
  }
  quizState.current += 1;
  renderQuizQuestion();
}

function prevQuestion() {
  quizState.current -= 1;
  renderQuizQuestion();
}

function submitQuiz() {
  var quiz = DB.quizzes.find(function (candidate) {
    return candidate.id === quizState.qid;
  });
  var score = 0;
  quiz.questions.forEach(function (question, index) {
    if (quizState.answers[index] === question.ans) score += 1;
  });
  DB.quizResults[quiz.id + '_' + currentUser.id] = { score: score, total: quiz.questions.length, date: new Date().toLocaleDateString() };
  var pct = Math.round(score / quiz.questions.length * 100);
  var passed = pct >= 60;
  openModal('Quiz Results', `
    <div style="text-align:center;padding:20px;">
      <div style="font-size:64px;margin-bottom:12px;">${passed ? 'Trophy' : 'Book'}</div>
      <div style="font-size:32px;font-weight:800;color:${passed ? 'var(--green)' : 'var(--red)'};">${score}/${quiz.questions.length}</div>
      <div style="font-size:18px;font-weight:600;margin:6px 0;">${pct}% - ${passed ? 'Passed!' : 'Keep practising'}</div>
      <div class="progress-bar" style="margin:16px auto;max-width:200px;"><div class="progress-fill" style="width:${pct}%;background:${passed ? 'var(--green)' : 'var(--red)'}"></div></div>
      <div style="font-size:13px;color:var(--muted);">Correct: ${score} - Wrong: ${quiz.questions.length - score}</div>
    </div>
  `, [{ label: 'Done', cls: 'btn-sm btn-primary', action: function () { closeModal(); navigate('stuQuizzes'); } }]);
}

function stuNotices(container) {
  renderNoticesPage(container, false);
}

function stuProfile(container) {
  var student = currentUser;
  var attendance = DB.attendance[student.id] || {};
  var allDays = Object.values(attendance).flat();
  var attendancePct = allDays.length ? Math.round(allDays.reduce(function (a, b) { return a + b; }, 0) / allDays.length * 100) : 0;
  renderProfilePage(container, student, [
    { label: 'Department', val: student.dept },
    { label: 'Year', val: 'Year ' + student.year },
    { label: 'Section', val: student.section },
    { label: 'Date of Birth', val: student.dob || '—' },
    { label: 'Guardian', val: student.guardian || '—' },
    { label: 'Overall Attendance', val: attendancePct + '%' },
  ]);
}
