const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const NVIDIA_API_KEY = process.env.NVIDIA_API_KEY;
const NVIDIA_ENDPOINT = process.env.NVIDIA_ENDPOINT || 'https://integrate.api.nvidia.com/v1/chat/completions';
const AI_CACHE = new Map();
const AI_RATE_LIMIT = new Map();
const AI_RATE_WINDOW_MS = 60 * 1000;
const AI_RATE_MAX = Number(process.env.AI_RATE_LIMIT || 20);

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

function send(res, statusCode, body, headers) {
  res.writeHead(statusCode, Object.assign({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }, headers || {}));
  res.end(body);
}

function contentTypeFor(filePath) {
  return MIME_TYPES[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

function safeJoin(root, targetPath) {
  const resolved = path.normalize(path.join(root, targetPath));
  return resolved.startsWith(root) ? resolved : null;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 2 * 1024 * 1024) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function cleanMessages(messages) {
  return Array.isArray(messages)
    ? messages.filter((message) => message && typeof message.content === 'string' && typeof message.role === 'string').map((message) => ({
      role: message.role,
      content: message.content,
    }))
    : [];
}

function rateLimitKey(req) {
  return (req.socket && req.socket.remoteAddress) ? req.socket.remoteAddress : 'unknown';
}

function isRateLimited(req) {
  const key = rateLimitKey(req);
  const now = Date.now();
  const bucket = (AI_RATE_LIMIT.get(key) || []).filter((timestamp) => now - timestamp < AI_RATE_WINDOW_MS);
  bucket.push(now);
  AI_RATE_LIMIT.set(key, bucket);
  return bucket.length > AI_RATE_MAX;
}

function cacheKey(provider, model, messages) {
  const hash = crypto.createHash('sha1').update(JSON.stringify({
    provider,
    model,
    messages,
  })).digest('hex');
  return provider + ':' + model + ':' + hash;
}

function buildNemotronRequest(payload) {
  const model = payload.model || 'nvidia/llama-3.1-nemotron-nano-8b-v1';
  const messages = cleanMessages(payload.messages);
  const temperature = typeof payload.temperature === 'number' ? payload.temperature : 0.3;

  return {
    endpoint: NVIDIA_ENDPOINT,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + NVIDIA_API_KEY,
    },
    body: {
      model,
      messages: messages,
      temperature,
      stream: Boolean(payload.stream),
    },
    parse: (json) => {
      const choice = json && Array.isArray(json.choices) ? json.choices[0] : null;
      if (!choice) return '';
      if (choice.message && typeof choice.message.content === 'string') return choice.message.content;
      if (choice.delta && typeof choice.delta.content === 'string') return choice.delta.content;
      return '';
    },
  };
}

async function runNemotron(payload) {
  if (!NVIDIA_API_KEY) {
    throw new Error('NVIDIA_API_KEY is not configured');
  }

  const config = buildNemotronRequest(payload);
  const messages = cleanMessages(payload.messages);
  const key = cacheKey('nvidia', payload.model || '', messages);
  const now = Date.now();
  const cached = AI_CACHE.get(key);
  if (cached && now - cached.timestamp < 5 * 60 * 1000) {
    return { reply: cached.reply, model: cached.model, provider: 'nvidia', cached: true };
  }

  const upstreamResponse = await fetch(config.endpoint, {
    method: 'POST',
    headers: config.headers,
    body: JSON.stringify(config.body),
  });

  const rawText = await upstreamResponse.text();
  if (!upstreamResponse.ok) {
    throw new Error(rawText || ('Upstream AI provider returned ' + upstreamResponse.status));
  }

  let json;
  try {
    json = rawText ? JSON.parse(rawText) : {};
  } catch (err) {
    json = {};
  }

  const reply = config.parse(json) || json.reply || json.output || rawText;
  AI_CACHE.set(key, {
    timestamp: now,
    reply: reply,
    model: payload.model || '',
  });
  return { reply: reply, model: payload.model || '', provider: 'nvidia', cached: false };
}

async function handleAiChat(req, res) {
  if (req.method === 'OPTIONS') {
    send(res, 204, '');
    return;
  }

  if (req.method !== 'POST') {
    send(res, 405, JSON.stringify({ error: 'Method not allowed' }), {
      'Content-Type': 'application/json; charset=utf-8',
    });
    return;
  }

  if (isRateLimited(req)) {
    send(res, 429, JSON.stringify({ error: 'Too many AI requests. Please slow down.' }), {
      'Content-Type': 'application/json; charset=utf-8',
    });
    return;
  }

  let payload;
  try {
    payload = JSON.parse(await readBody(req) || '{}');
  } catch (err) {
    send(res, 400, JSON.stringify({ error: 'Invalid JSON body' }), {
      'Content-Type': 'application/json; charset=utf-8',
    });
    return;
  }

  try {
    const result = await runNemotron(payload);
    send(res, 200, JSON.stringify(result), {
      'Content-Type': 'application/json; charset=utf-8',
    });
  } catch (err) {
    send(res, 502, JSON.stringify({ error: err.message, provider: 'nvidia' }), {
      'Content-Type': 'application/json; charset=utf-8',
    });
  }
}

async function handleAttendanceChat(req, res) {
  await handleAiChat(req, res);
}

function serveStatic(req, res, pathname) {
  const filePath = pathname === '/'
    ? path.join(ROOT, 'index.html')
    : safeJoin(ROOT, decodeURIComponent(pathname.slice(1)));

  if (!filePath) {
    send(res, 403, 'Forbidden', { 'Content-Type': 'text/plain; charset=utf-8' });
    return;
  }

  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
      return;
    }

    fs.readFile(filePath, (readErr, data) => {
      if (readErr) {
        send(res, 500, 'Failed to read file', { 'Content-Type': 'text/plain; charset=utf-8' });
        return;
      }

      send(res, 200, data, { 'Content-Type': contentTypeFor(filePath) });
    });
  });
}

const server = http.createServer((req, res) => {
  const requestUrl = new URL(req.url, 'http://localhost:' + PORT);

  if (requestUrl.pathname === '/api/attendance-chat') {
    handleAttendanceChat(req, res).catch((err) => {
      send(res, 500, JSON.stringify({ error: err.message }), {
        'Content-Type': 'application/json; charset=utf-8',
      });
    });
    return;
  }

  if (requestUrl.pathname === '/api/ai/chat') {
    handleAiChat(req, res).catch((err) => {
      send(res, 500, JSON.stringify({ error: err.message }), {
        'Content-Type': 'application/json; charset=utf-8',
      });
    });
    return;
  }

  if (req.method === 'OPTIONS') {
    send(res, 204, '');
    return;
  }

  serveStatic(req, res, requestUrl.pathname);
});

server.listen(PORT, () => {
  console.log(`UniERP server running at http://localhost:${PORT}`);
});
